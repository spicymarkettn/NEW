import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class SupabaseService {
  static SupabaseService? _instance;
  static SupabaseService get instance => _instance ??= SupabaseService._();

  SupabaseService._();

  static bool _initialized = false;
  static bool get isInitialized => _initialized;

  /// Initialize Supabase — reads credentials from assets/env.json.
  /// Falls back to --dart-define values if the file is missing or empty.
  static Future<void> initialize() async {
    String url = const String.fromEnvironment('SUPABASE_URL', defaultValue: '');
    String anonKey =
        const String.fromEnvironment('SUPABASE_ANON_KEY', defaultValue: '');

    // Try loading from bundled env.json first
    try {
      final raw = await rootBundle.loadString('assets/env.json');
      final Map<String, dynamic> env = json.decode(raw);
      final fileUrl = (env['SUPABASE_URL'] as String? ?? '').trim();
      final fileKey = (env['SUPABASE_ANON_KEY'] as String? ?? '').trim();
      if (fileUrl.isNotEmpty) url = fileUrl;
      if (fileKey.isNotEmpty) anonKey = fileKey;
    } catch (_) {
      // env.json not found or malformed — continue with dart-define values
    }

    if (url.isEmpty || anonKey.isEmpty) {
      throw Exception(
        'Supabase credentials are missing.\n'
        'Add your SUPABASE_URL and SUPABASE_ANON_KEY to assets/env.json.',
      );
    }

    await Supabase.initialize(url: url, anonKey: anonKey);
    _initialized = true;
  }

  /// Returns null if Supabase was never initialized (e.g. missing credentials).
  static SupabaseClient? get clientOrNull {
    if (!_initialized) return null;
    try {
      return Supabase.instance.client;
    } catch (_) {
      return null;
    }
  }

  // Convenience getter — throws if not initialized
  SupabaseClient get client => Supabase.instance.client;
}
