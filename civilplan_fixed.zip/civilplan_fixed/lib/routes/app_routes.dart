import 'package:flutter/material.dart';

import '../presentation/project_detail_screen/project_detail_screen.dart';
import '../presentation/projects_dashboard_screen/projects_dashboard_screen.dart';
import '../presentation/sign_up_login_screen/sign_up_login_screen.dart';
import '../presentation/profile_screen/profile_screen.dart';

class AppRoutes {
  static const String initial = '/';
  static const String signUpLoginScreen = '/sign-up-login-screen';
  static const String projectsDashboardScreen = '/projects-dashboard-screen';
  static const String projectDetailScreen = '/project-detail-screen';
  static const String profileScreen = '/profile-screen';

  static Map<String, WidgetBuilder> routes = {
    initial: (context) => const SignUpLoginScreen(),
    signUpLoginScreen: (context) => const SignUpLoginScreen(),
    projectsDashboardScreen: (context) => const ProjectsDashboardScreen(),
    projectDetailScreen: (context) => const ProjectDetailScreen(),
    profileScreen: (context) => const ProfileScreen(),
  };
}
