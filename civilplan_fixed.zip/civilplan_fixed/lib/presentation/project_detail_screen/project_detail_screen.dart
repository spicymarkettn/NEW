import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../theme/app_theme.dart';
import '../../widgets/status_badge_widget.dart';
import './widgets/budget_tab_widget.dart';
import './widgets/documents_tab_widget.dart';
import './widgets/overview_tab_widget.dart';
import './widgets/project_detail_header_widget.dart';
import './widgets/tasks_tab_widget.dart';

class ProjectDetailScreen extends StatefulWidget {
  const ProjectDetailScreen({super.key});

  @override
  State<ProjectDetailScreen> createState() => _ProjectDetailScreenState();
}

class _ProjectDetailScreenState extends State<ProjectDetailScreen>
    with TickerProviderStateMixin {
  // TODO: Replace with Riverpod/Bloc for production
  late TabController _tabController;
  int _currentTab = 0;

  // Default project data — overridden by route arguments
  Map<String, dynamic> _project = {
    'id': 'PRJ-002',
    'name': 'Lekki-Epe Highway Expansion',
    'client': 'FERMA',
    'status': 'delayed',
    'schedulePercent': 42,
    'budgetPercent': 105,
    'budgetTotal': 12800000,
    'budgetSpent': 13440000,
    'daysRemaining': -18,
    'lastUpdated': '5h ago',
    'location': 'Lagos, Nigeria',
    'teamSize': 68,
    'openTasks': 31,
    'startDate': 'Mar 15, 2025',
    'endDate': 'Dec 30, 2026',
    'contractValue': 12800000,
    'engineer': 'Amara Nwosu',
    'description':
        'Expansion of the Lekki-Epe Expressway from 4 to 8 lanes, including new interchange at Ajah, bridge widening at Sangotedo, and drainage infrastructure upgrade across 42km.',
  };

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
    _tabController.addListener(() {
      if (!_tabController.indexIsChanging) {
        setState(() => _currentTab = _tabController.index);
      }
    });
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final args = ModalRoute.of(context)?.settings.arguments;
    if (args is Map<String, dynamic>) {
      setState(() => _project = args);
    }
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  ProjectStatus _parseStatus(String s) {
    switch (s) {
      case 'onTrack':
        return ProjectStatus.onTrack;
      case 'atRisk':
        return ProjectStatus.atRisk;
      case 'delayed':
        return ProjectStatus.delayed;
      case 'completed':
        return ProjectStatus.completed;
      case 'planning':
        return ProjectStatus.planning;
      case 'onHold':
        return ProjectStatus.onHold;
      default:
        return ProjectStatus.onTrack;
    }
  }

  void _showEditProjectSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _EditProjectSheet(
        project: _project,
        onSaved: (updated) {
          setState(() => _project = updated);
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final status = _parseStatus(_project['status'] as String);

    SystemChrome.setSystemUIOverlayStyle(
      SystemUiOverlayStyle.light.copyWith(statusBarColor: Colors.transparent),
    );

    return Scaffold(
      backgroundColor: AppTheme.background,
      body: NestedScrollView(
        headerSliverBuilder: (context, innerBoxIsScrolled) => [
          SliverOverlapAbsorber(
            handle: NestedScrollView.sliverOverlapAbsorberHandleFor(context),
            sliver: SliverAppBar(
              expandedHeight: 220,
              pinned: true,
              floating: false,
              backgroundColor: AppTheme.primaryDark,
              foregroundColor: Colors.white,
              scrolledUnderElevation: 0,
              leading: IconButton(
                icon: const Icon(Icons.arrow_back_rounded, color: Colors.white),
                onPressed: () => Navigator.pop(context),
              ),
              actions: [
                IconButton(
                  icon: const Icon(
                    Icons.edit_outlined,
                    color: Colors.white,
                    size: 22,
                  ),
                  tooltip: 'Edit Project',
                  onPressed: _showEditProjectSheet,
                ),
                IconButton(
                  icon: const Icon(
                    Icons.share_outlined,
                    color: Colors.white,
                    size: 22,
                  ),
                  onPressed: () {},
                ),
                IconButton(
                  icon: const Icon(
                    Icons.more_vert_rounded,
                    color: Colors.white,
                    size: 22,
                  ),
                  onPressed: () => _showProjectActions(context),
                ),
              ],
              flexibleSpace: FlexibleSpaceBar(
                collapseMode: CollapseMode.parallax,
                background: ProjectDetailHeaderWidget(
                  project: _project,
                  status: status,
                ),
              ),
              bottom: PreferredSize(
                preferredSize: const Size.fromHeight(48),
                child: Container(
                  color: AppTheme.surface,
                  child: TabBar(
                    controller: _tabController,
                    isScrollable: false,
                    tabs: const [
                      Tab(text: 'Overview'),
                      Tab(text: 'Tasks'),
                      Tab(text: 'Budget'),
                      Tab(text: 'Documents'),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
        body: TabBarView(
          controller: _tabController,
          children: [
            OverviewTabWidget(project: _project),
            TasksTabWidget(project: _project),
            BudgetTabWidget(project: _project),
            DocumentsTabWidget(project: _project),
          ],
        ),
      ),
      floatingActionButton: _buildContextualFab(),
    );
  }

  Widget? _buildContextualFab() {
    switch (_currentTab) {
      case 1:
        return FloatingActionButton.extended(
          onPressed: () {},
          icon: const Icon(Icons.add_task_rounded),
          label: const Text('Add Task'),
          backgroundColor: AppTheme.primary,
          foregroundColor: Colors.white,
          elevation: 2,
        );
      case 3:
        return FloatingActionButton.extended(
          onPressed: () {},
          icon: const Icon(Icons.upload_file_rounded),
          label: const Text('Upload Document'),
          backgroundColor: AppTheme.primary,
          foregroundColor: Colors.white,
          elevation: 2,
        );
      default:
        return null;
    }
  }

  void _showProjectActions(BuildContext context) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (_) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 36,
              height: 4,
              margin: const EdgeInsets.only(top: 12, bottom: 8),
              decoration: BoxDecoration(
                color: const Color(0xFFD1D5DB),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            _buildActionItem(
              Icons.edit_outlined,
              'Edit Project Details',
              () => _showEditProjectSheet(),
            ),
            _buildActionItem(
              Icons.summarize_outlined,
              'Generate Progress Report',
              () {},
            ),
            _buildActionItem(
              Icons.share_outlined,
              'Share Project Summary',
              () {},
            ),
            _buildActionItem(Icons.archive_outlined, 'Archive Project', () {}),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  Widget _buildActionItem(IconData icon, String label, VoidCallback onTap) {
    return ListTile(
      leading: Icon(icon, size: 20, color: AppTheme.onSurface),
      title: Text(
        label,
        style: GoogleFonts.ibmPlexSans(
          fontSize: 14,
          fontWeight: FontWeight.w500,
        ),
      ),
      onTap: () {
        Navigator.pop(context);
        onTap();
      },
      dense: true,
    );
  }
}

// ─── Edit Project Sheet (inline in detail screen) ─────────────────────────────

class _EditProjectSheet extends StatefulWidget {
  final Map<String, dynamic> project;
  final Function(Map<String, dynamic>) onSaved;

  const _EditProjectSheet({required this.project, required this.onSaved});

  @override
  State<_EditProjectSheet> createState() => _EditProjectSheetState();
}

class _EditProjectSheetState extends State<_EditProjectSheet> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _nameCtrl;
  late TextEditingController _clientCtrl;
  late TextEditingController _locationCtrl;
  late TextEditingController _engineerCtrl;
  late TextEditingController _descCtrl;
  late TextEditingController _budgetCtrl;
  late TextEditingController _scheduleCtrl;
  late String _selectedStatus;
  bool _isSaving = false;

  final List<Map<String, String>> _statusOptions = [
    {'value': 'planning', 'label': 'Planning'},
    {'value': 'onTrack', 'label': 'On Track'},
    {'value': 'atRisk', 'label': 'At Risk'},
    {'value': 'delayed', 'label': 'Delayed'},
    {'value': 'onHold', 'label': 'On Hold'},
    {'value': 'completed', 'label': 'Completed'},
  ];

  @override
  void initState() {
    super.initState();
    final p = widget.project;
    _nameCtrl = TextEditingController(text: p['name'] as String? ?? '');
    _clientCtrl = TextEditingController(text: p['client'] as String? ?? '');
    _locationCtrl = TextEditingController(text: p['location'] as String? ?? '');
    _engineerCtrl = TextEditingController(text: p['engineer'] as String? ?? '');
    _descCtrl = TextEditingController(text: p['description'] as String? ?? '');
    _budgetCtrl = TextEditingController(
      text: (p['budgetTotal'] as num?)?.toStringAsFixed(0) ?? '0',
    );
    _scheduleCtrl = TextEditingController(
      text: (p['schedulePercent'] as int?)?.toString() ?? '0',
    );
    _selectedStatus = p['status'] as String? ?? 'planning';
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _clientCtrl.dispose();
    _locationCtrl.dispose();
    _engineerCtrl.dispose();
    _descCtrl.dispose();
    _budgetCtrl.dispose();
    _scheduleCtrl.dispose();
    super.dispose();
  }

  void _save() {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _isSaving = true);

    final budget = double.tryParse(_budgetCtrl.text.replaceAll(',', '')) ?? 0.0;
    final schedule = int.tryParse(_scheduleCtrl.text) ?? 0;
    final budgetSpent = widget.project['budgetSpent'] as num? ?? 0;
    final budgetPct = budget > 0 ? ((budgetSpent / budget) * 100).round() : 0;

    final updated = Map<String, dynamic>.from(widget.project)
      ..['name'] = _nameCtrl.text.trim()
      ..['client'] = _clientCtrl.text.trim()
      ..['location'] = _locationCtrl.text.trim()
      ..['engineer'] = _engineerCtrl.text.trim()
      ..['description'] = _descCtrl.text.trim()
      ..['budgetTotal'] = budget
      ..['contractValue'] = budget
      ..['schedulePercent'] = schedule.clamp(0, 100)
      ..['budgetPercent'] = budgetPct
      ..['status'] = _selectedStatus
      ..['lastUpdated'] = 'Just now';

    Future.delayed(const Duration(milliseconds: 400), () {
      if (mounted) {
        Navigator.pop(context);
        widget.onSaved(updated);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final bottomPad = MediaQuery.of(context).viewInsets.bottom;
    return Container(
      decoration: const BoxDecoration(
        color: AppTheme.surface,
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      padding: EdgeInsets.fromLTRB(20, 0, 20, bottomPad + 20),
      child: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 36,
                  height: 4,
                  margin: const EdgeInsets.only(top: 12, bottom: 16),
                  decoration: BoxDecoration(
                    color: const Color(0xFFD1D5DB),
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              Row(
                children: [
                  Expanded(
                    child: Text(
                      'Edit Project',
                      style: GoogleFonts.ibmPlexSans(
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        color: AppTheme.onSurface,
                      ),
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: AppTheme.primaryContainer,
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(
                      widget.project['id'] as String? ?? '',
                      style: GoogleFonts.ibmPlexMono(
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                        color: AppTheme.primary,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 4),
              Text(
                'Update project information',
                style: GoogleFonts.ibmPlexSans(
                  fontSize: 13,
                  color: AppTheme.muted,
                ),
              ),
              const SizedBox(height: 20),
              _buildField(
                'Project Name *',
                _nameCtrl,
                'Project name',
                validator: (v) =>
                    (v == null || v.trim().isEmpty) ? 'Required' : null,
              ),
              const SizedBox(height: 14),
              _buildField(
                'Client / Owner *',
                _clientCtrl,
                'Client name',
                validator: (v) =>
                    (v == null || v.trim().isEmpty) ? 'Required' : null,
              ),
              const SizedBox(height: 14),
              Row(
                children: [
                  Expanded(
                    child: _buildField(
                      'Location',
                      _locationCtrl,
                      'City, Country',
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _buildField('Lead Engineer', _engineerCtrl, 'Name'),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              Row(
                children: [
                  Expanded(
                    child: _buildField(
                      'Contract Budget (USD)',
                      _budgetCtrl,
                      '0',
                      keyboardType: TextInputType.number,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _buildField(
                      'Schedule %',
                      _scheduleCtrl,
                      '0–100',
                      keyboardType: TextInputType.number,
                      validator: (v) {
                        final n = int.tryParse(v ?? '');
                        if (n == null || n < 0 || n > 100) return '0–100';
                        return null;
                      },
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Status',
                    style: GoogleFonts.ibmPlexSans(
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      color: AppTheme.onSurface,
                    ),
                  ),
                  const SizedBox(height: 6),
                  DropdownButtonFormField<String>(
                    initialValue: _selectedStatus,
                    decoration: InputDecoration(
                      filled: true,
                      fillColor: AppTheme.surfaceVariant,
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 14,
                        vertical: 12,
                      ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: const BorderSide(color: Color(0xFFE5E7EB)),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: const BorderSide(color: Color(0xFFE5E7EB)),
                      ),
                    ),
                    items: _statusOptions
                        .map(
                          (s) => DropdownMenuItem(
                            value: s['value'],
                            child: Text(
                              s['label']!,
                              style: GoogleFonts.ibmPlexSans(fontSize: 14),
                            ),
                          ),
                        )
                        .toList(),
                    onChanged: (v) =>
                        setState(() => _selectedStatus = v ?? 'planning'),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              _buildField(
                'Description',
                _descCtrl,
                'Project scope and objectives',
                maxLines: 3,
              ),
              const SizedBox(height: 24),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.pop(context),
                      child: const Text('Cancel'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    flex: 2,
                    child: ElevatedButton(
                      onPressed: _isSaving ? null : _save,
                      child: _isSaving
                          ? const SizedBox(
                              height: 18,
                              width: 18,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Colors.white,
                              ),
                            )
                          : const Text('Save Changes'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildField(
    String label,
    TextEditingController controller,
    String hint, {
    String? Function(String?)? validator,
    TextInputType keyboardType = TextInputType.text,
    int maxLines = 1,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: GoogleFonts.ibmPlexSans(
            fontSize: 13,
            fontWeight: FontWeight.w600,
            color: AppTheme.onSurface,
          ),
        ),
        const SizedBox(height: 6),
        TextFormField(
          controller: controller,
          keyboardType: keyboardType,
          maxLines: maxLines,
          validator: validator,
          style: GoogleFonts.ibmPlexSans(
            fontSize: 14,
            color: AppTheme.onSurface,
          ),
          decoration: InputDecoration(
            hintText: hint,
            filled: true,
            fillColor: AppTheme.surfaceVariant,
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 14,
              vertical: 12,
            ),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: const BorderSide(color: Color(0xFFE5E7EB)),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: const BorderSide(color: Color(0xFFE5E7EB)),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: const BorderSide(color: AppTheme.primary, width: 2),
            ),
            errorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: const BorderSide(color: AppTheme.errorColor),
            ),
          ),
        ),
      ],
    );
  }
}
