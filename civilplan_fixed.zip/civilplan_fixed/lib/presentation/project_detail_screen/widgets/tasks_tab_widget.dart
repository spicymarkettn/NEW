import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../theme/app_theme.dart';
import '../../../widgets/status_badge_widget.dart';
import '../../../widgets/empty_state_widget.dart';

class TasksTabWidget extends StatefulWidget {
  final Map<String, dynamic> project;

  const TasksTabWidget({super.key, required this.project});

  @override
  State<TasksTabWidget> createState() => _TasksTabWidgetState();
}

class _TasksTabWidgetState extends State<TasksTabWidget> {
  // TODO: Replace with actual task data from repository in production
  static final List<Map<String, dynamic>> _taskMaps = [
    // Phase: Drainage Infrastructure
    {
      'id': 'T-041',
      'phase': 'Drainage Infrastructure',
      'name': 'Install culvert at Ch.14+200',
      'assignee': 'Chidi Eze',
      'dueDate': 'Apr 30, 2026',
      'priority': 'high',
      'status': 'inProgress',
      'isCompleted': false,
    },
    {
      'id': 'T-042',
      'phase': 'Drainage Infrastructure',
      'name': 'Concrete lining for open drain — Segment D4',
      'assignee': 'Ngozi Adeyemi',
      'dueDate': 'May 05, 2026',
      'priority': 'high',
      'status': 'pending',
      'isCompleted': false,
    },
    {
      'id': 'T-043',
      'phase': 'Drainage Infrastructure',
      'name': 'Backfill and compaction Ch.11+800 to Ch.12+600',
      'assignee': 'Kwame Asante',
      'dueDate': 'Apr 28, 2026',
      'priority': 'medium',
      'status': 'blocked',
      'isCompleted': false,
    },
    {
      'id': 'T-044',
      'phase': 'Drainage Infrastructure',
      'name': 'Outfall structure at Sangotedo creek',
      'assignee': 'Chidi Eze',
      'dueDate': 'May 12, 2026',
      'priority': 'medium',
      'status': 'pending',
      'isCompleted': false,
    },
    // Phase: Pavement Base Course
    {
      'id': 'T-055',
      'phase': 'Pavement Base Course',
      'name': 'Sub-base compaction test — Section B',
      'assignee': 'Fatima Al-Rashid',
      'dueDate': 'Apr 25, 2026',
      'priority': 'high',
      'status': 'inProgress',
      'isCompleted': false,
    },
    {
      'id': 'T-056',
      'phase': 'Pavement Base Course',
      'name': 'Aggregate delivery coordination — Crusher Run',
      'assignee': 'Remi Okonkwo',
      'dueDate': 'Apr 22, 2026',
      'priority': 'high',
      'status': 'completed',
      'isCompleted': true,
    },
    {
      'id': 'T-057',
      'phase': 'Pavement Base Course',
      'name': 'Prime coat application — Northbound carriageway',
      'assignee': 'Emeka Obi',
      'dueDate': 'May 20, 2026',
      'priority': 'medium',
      'status': 'pending',
      'isCompleted': false,
    },
    // Phase: Site Administration
    {
      'id': 'T-061',
      'phase': 'Site Administration',
      'name': 'Submit weekly progress report W25',
      'assignee': 'Remi Okonkwo',
      'dueDate': 'Apr 26, 2026',
      'priority': 'medium',
      'status': 'inProgress',
      'isCompleted': false,
    },
    {
      'id': 'T-062',
      'phase': 'Site Administration',
      'name': 'Update ITP for concrete works',
      'assignee': 'Amara Nwosu',
      'dueDate': 'Apr 24, 2026',
      'priority': 'low',
      'status': 'completed',
      'isCompleted': true,
    },
    {
      'id': 'T-063',
      'phase': 'Site Administration',
      'name': 'HSE toolbox talk — crane operations',
      'assignee': 'Yetunde Bello',
      'dueDate': 'Apr 29, 2026',
      'priority': 'high',
      'status': 'pending',
      'isCompleted': false,
    },
    {
      'id': 'T-064',
      'phase': 'Site Administration',
      'name': 'Renew site security contract',
      'assignee': 'Remi Okonkwo',
      'dueDate': 'May 01, 2026',
      'priority': 'low',
      'status': 'pending',
      'isCompleted': false,
    },
  ];

  late List<Map<String, dynamic>> _tasks;
  String _filterStatus = 'all';

  @override
  void initState() {
    super.initState();
    // TODO: Replace with actual data loading in production
    _tasks = _taskMaps.map((m) => Map<String, dynamic>.from(m)).toList();
  }

  List<Map<String, dynamic>> get _filteredTasks {
    if (_filterStatus == 'all') return _tasks;
    return _tasks.where((t) => t['status'] as String == _filterStatus).toList();
  }

  Map<String, List<Map<String, dynamic>>> get _groupedTasks {
    final grouped = <String, List<Map<String, dynamic>>>{};
    for (final task in _filteredTasks) {
      final phase = task['phase'] as String;
      grouped.putIfAbsent(phase, () => []).add(task);
    }
    return grouped;
  }

  void _toggleTaskComplete(String taskId) {
    // TODO: Replace with actual task update in production
    setState(() {
      final idx = _tasks.indexWhere((t) => t['id'] == taskId);
      if (idx != -1) {
        final current = _tasks[idx]['isCompleted'] as bool;
        _tasks[idx] = Map<String, dynamic>.from(_tasks[idx]);
        _tasks[idx]['isCompleted'] = !current;
        _tasks[idx]['status'] = !current ? 'completed' : 'pending';
      }
    });
  }

  TaskStatus _parseTaskStatus(String s) {
    switch (s) {
      case 'pending':
        return TaskStatus.pending;
      case 'inProgress':
        return TaskStatus.inProgress;
      case 'completed':
        return TaskStatus.completed;
      case 'blocked':
        return TaskStatus.blocked;
      default:
        return TaskStatus.pending;
    }
  }

  @override
  Widget build(BuildContext context) {
    final grouped = _groupedTasks;

    return Builder(
      builder: (context) => CustomScrollView(
        slivers: [
          SliverOverlapInjector(
            handle: NestedScrollView.sliverOverlapAbsorberHandleFor(context),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Filter chips
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: [
                        _buildFilterChip('all', 'All Tasks'),
                        const SizedBox(width: 8),
                        _buildFilterChip('inProgress', 'In Progress'),
                        const SizedBox(width: 8),
                        _buildFilterChip('pending', 'Pending'),
                        const SizedBox(width: 8),
                        _buildFilterChip('blocked', 'Blocked'),
                        const SizedBox(width: 8),
                        _buildFilterChip('completed', 'Completed'),
                      ],
                    ),
                  ),
                  const SizedBox(height: 6),
                  // Stats row
                  Row(
                    children: [
                      Text(
                        '${_filteredTasks.length} tasks',
                        style: GoogleFonts.ibmPlexSans(
                          fontSize: 12,
                          color: AppTheme.muted,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Text(
                        '${_tasks.where((t) => t['isCompleted'] == true).length} completed',
                        style: GoogleFonts.ibmPlexSans(
                          fontSize: 12,
                          color: AppTheme.secondary,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Text(
                        '${_tasks.where((t) => t['status'] == 'blocked').length} blocked',
                        style: GoogleFonts.ibmPlexSans(
                          fontSize: 12,
                          color: AppTheme.errorColor,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          if (grouped.isEmpty)
            SliverFillRemaining(
              child: EmptyStateWidget(
                icon: Icons.checklist_rounded,
                title: 'No tasks match this filter',
                description:
                    'Try a different filter or add new tasks to this project phase.',
                actionLabel: 'Add Task',
                onAction: () {},
              ),
            )
          else
            SliverList(
              delegate: SliverChildBuilderDelegate((context, index) {
                final phases = grouped.keys.toList();
                final phase = phases[index];
                final tasks = grouped[phase]!;
                return Padding(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
                  child: _buildPhaseSection(phase, tasks),
                );
              }, childCount: grouped.length),
            ),
          const SliverToBoxAdapter(child: SizedBox(height: 100)),
        ],
      ),
    );
  }

  Widget _buildPhaseSection(String phase, List<Map<String, dynamic>> tasks) {
    final completedCount = tasks.where((t) => t['isCompleted'] == true).length;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Phase header
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                Container(
                  width: 3,
                  height: 14,
                  decoration: BoxDecoration(
                    color: AppTheme.primary,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  phase,
                  style: GoogleFonts.ibmPlexSans(
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: AppTheme.onSurface,
                  ),
                ),
              ],
            ),
            Text(
              '$completedCount/${tasks.length}',
              style: GoogleFonts.ibmPlexMono(
                fontSize: 11,
                color: AppTheme.muted,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            color: AppTheme.surface,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: const Color(0xFFE5E7EB), width: 1),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withAlpha(10),
                blurRadius: 8,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Column(
            children: List.generate(tasks.length, (i) {
              final task = tasks[i];
              final isLast = i == tasks.length - 1;
              return _buildTaskRow(task, isLast);
            }),
          ),
        ),
      ],
    );
  }

  Widget _buildTaskRow(Map<String, dynamic> task, bool isLast) {
    final isCompleted = task['isCompleted'] as bool;
    final status = _parseTaskStatus(task['status'] as String);
    final priority = task['priority'] as String;

    Color priorityColor;
    switch (priority) {
      case 'high':
        priorityColor = AppTheme.errorColor;
        break;
      case 'medium':
        priorityColor = AppTheme.warning;
        break;
      default:
        priorityColor = AppTheme.muted;
    }

    return InkWell(
      onTap: () {},
      borderRadius: isLast
          ? const BorderRadius.vertical(bottom: Radius.circular(12))
          : BorderRadius.zero,
      splashColor: AppTheme.primary.withAlpha(13),
      child: Container(
        padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
        decoration: BoxDecoration(
          color: isCompleted
              ? AppTheme.surfaceVariant.withAlpha(128)
              : AppTheme.surface,
          border: isLast
              ? null
              : const Border(
                  bottom: BorderSide(color: Color(0xFFF3F4F6), width: 1),
                ),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Checkbox
            GestureDetector(
              onTap: () => _toggleTaskComplete(task['id'] as String),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                width: 22,
                height: 22,
                margin: const EdgeInsets.only(top: 1),
                decoration: BoxDecoration(
                  color: isCompleted ? AppTheme.secondary : Colors.transparent,
                  border: Border.all(
                    color: isCompleted
                        ? AppTheme.secondary
                        : const Color(0xFFD1D5DB),
                    width: 1.5,
                  ),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: isCompleted
                    ? const Icon(
                        Icons.check_rounded,
                        size: 14,
                        color: Colors.white,
                      )
                    : null,
              ),
            ),
            const SizedBox(width: 10),
            // Content
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          task['name'] as String,
                          style: GoogleFonts.ibmPlexSans(
                            fontSize: 13,
                            fontWeight: FontWeight.w500,
                            color: isCompleted
                                ? AppTheme.muted
                                : AppTheme.onSurface,
                            decoration: isCompleted
                                ? TextDecoration.lineThrough
                                : null,
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      // Priority dot
                      Container(
                        width: 6,
                        height: 6,
                        decoration: BoxDecoration(
                          color: priorityColor,
                          shape: BoxShape.circle,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 5),
                  Row(
                    children: [
                      Icon(
                        Icons.person_outline_rounded,
                        size: 11,
                        color: AppTheme.muted,
                      ),
                      const SizedBox(width: 3),
                      Text(
                        task['assignee'] as String,
                        style: GoogleFonts.ibmPlexSans(
                          fontSize: 11,
                          color: AppTheme.muted,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Icon(
                        Icons.calendar_today_outlined,
                        size: 11,
                        color: AppTheme.muted,
                      ),
                      const SizedBox(width: 3),
                      Text(
                        task['dueDate'] as String,
                        style: GoogleFonts.ibmPlexSans(
                          fontSize: 11,
                          color: AppTheme.muted,
                        ),
                      ),
                      const Spacer(),
                      StatusBadgeWidget.fromTaskStatus(status),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFilterChip(String value, String label) {
    final isSelected = _filterStatus == value;
    return GestureDetector(
      onTap: () => setState(() => _filterStatus = value),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: isSelected ? AppTheme.primary : AppTheme.surface,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: isSelected ? AppTheme.primary : const Color(0xFFE5E7EB),
            width: 1,
          ),
        ),
        child: Text(
          label,
          style: GoogleFonts.ibmPlexSans(
            fontSize: 12,
            fontWeight: FontWeight.w500,
            color: isSelected ? Colors.white : AppTheme.muted,
          ),
        ),
      ),
    );
  }
}
