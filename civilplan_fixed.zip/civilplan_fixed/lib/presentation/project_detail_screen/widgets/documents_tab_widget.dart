import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../theme/app_theme.dart';
import '../../../widgets/empty_state_widget.dart';

class DocumentsTabWidget extends StatefulWidget {
  final Map<String, dynamic> project;

  const DocumentsTabWidget({super.key, required this.project});

  @override
  State<DocumentsTabWidget> createState() => _DocumentsTabWidgetState();
}

class _DocumentsTabWidgetState extends State<DocumentsTabWidget> {
  // TODO: Replace with actual document data from repository in production
  static final List<Map<String, dynamic>> _documentMaps = [
    {
      'id': 'DOC-001',
      'name': 'Lekki-Epe Highway Expansion — Contract Drawings Set A',
      'type': 'DWG',
      'category': 'Drawings',
      'version': 'Rev 3',
      'uploadedBy': 'Amara Nwosu',
      'uploadDate': 'Apr 18, 2026',
      'fileSize': '24.7 MB',
      'status': 'approved',
    },
    {
      'id': 'DOC-002',
      'name': 'Geotechnical Investigation Report — Sangotedo Section',
      'type': 'PDF',
      'category': 'Reports',
      'version': 'Final',
      'uploadedBy': 'Dr. Kola Adewale',
      'uploadDate': 'Feb 05, 2026',
      'fileSize': '8.2 MB',
      'status': 'approved',
    },
    {
      'id': 'DOC-003',
      'name': 'Inspection & Test Plan — Concrete Works',
      'type': 'PDF',
      'category': 'QA/QC',
      'version': 'Rev 2',
      'uploadedBy': 'Fatima Al-Rashid',
      'uploadDate': 'Apr 22, 2026',
      'fileSize': '3.1 MB',
      'status': 'pending_review',
    },
    {
      'id': 'DOC-004',
      'name': 'Drainage Design Calculations — Revised Scope',
      'type': 'PDF',
      'category': 'Engineering',
      'version': 'Rev 1',
      'uploadedBy': 'Chidi Eze',
      'uploadDate': 'Apr 10, 2026',
      'fileSize': '5.4 MB',
      'status': 'approved',
    },
    {
      'id': 'DOC-005',
      'name': 'Method Statement — Earthworks & Compaction',
      'type': 'PDF',
      'category': 'Method Statements',
      'version': 'Rev 0',
      'uploadedBy': 'Kwame Asante',
      'uploadDate': 'Jan 15, 2026',
      'fileSize': '2.8 MB',
      'status': 'approved',
    },
    {
      'id': 'DOC-006',
      'name': 'Structural Drawings — Ajah Interchange Overpass',
      'type': 'DWG',
      'category': 'Drawings',
      'version': 'Rev 1',
      'uploadedBy': 'Amara Nwosu',
      'uploadDate': 'Mar 30, 2026',
      'fileSize': '41.3 MB',
      'status': 'pending_review',
    },
    {
      'id': 'DOC-007',
      'name': 'IFC Model — Highway Alignment BIM',
      'type': 'IFC',
      'category': 'BIM',
      'version': 'Stage 4',
      'uploadedBy': 'Ngozi Adeyemi',
      'uploadDate': 'Apr 01, 2026',
      'fileSize': '186.4 MB',
      'status': 'approved',
    },
    {
      'id': 'DOC-008',
      'name': 'HSE Management Plan — Site Operations',
      'type': 'PDF',
      'category': 'HSE',
      'version': 'Rev 4',
      'uploadedBy': 'Yetunde Bello',
      'uploadDate': 'Apr 20, 2026',
      'fileSize': '4.6 MB',
      'status': 'approved',
    },
    {
      'id': 'DOC-009',
      'name': 'Weekly Progress Report — W24 (Apr 14–20, 2026)',
      'type': 'PDF',
      'category': 'Reports',
      'version': 'Final',
      'uploadedBy': 'Remi Okonkwo',
      'uploadDate': 'Apr 21, 2026',
      'fileSize': '1.9 MB',
      'status': 'approved',
    },
    {
      'id': 'DOC-010',
      'name': 'Variation Order #9 — Shoulder Widening Extension',
      'type': 'PDF',
      'category': 'Contracts',
      'version': 'Draft',
      'uploadedBy': 'Remi Okonkwo',
      'uploadDate': 'Apr 23, 2026',
      'fileSize': '0.8 MB',
      'status': 'pending_review',
    },
  ];

  String _filterCategory = 'All';
  String _searchQuery = '';
  final _searchController = TextEditingController();

  final List<String> _categories = [
    'All',
    'Drawings',
    'Reports',
    'QA/QC',
    'Engineering',
    'BIM',
    'HSE',
    'Contracts',
    'Method Statements',
  ];

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  List<Map<String, dynamic>> get _filteredDocs {
    return _documentMaps.where((doc) {
      final matchCategory =
          _filterCategory == 'All' || doc['category'] == _filterCategory;
      final matchSearch =
          _searchQuery.isEmpty ||
          (doc['name'] as String).toLowerCase().contains(
            _searchQuery.toLowerCase(),
          );
      return matchCategory && matchSearch;
    }).toList();
  }

  Color _typeColor(String type) {
    switch (type) {
      case 'DWG':
        return const Color(0xFF1A56A0);
      case 'IFC':
        return const Color(0xFF6D4C9E);
      case 'PDF':
        return const Color(0xFFB91C1C);
      default:
        return AppTheme.muted;
    }
  }

  @override
  Widget build(BuildContext context) {
    final filtered = _filteredDocs;

    return Builder(
      builder: (context) => CustomScrollView(
        slivers: [
          SliverOverlapInjector(
            handle: NestedScrollView.sliverOverlapAbsorberHandleFor(context),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Search bar
                  Container(
                    height: 42,
                    decoration: BoxDecoration(
                      color: AppTheme.surface,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: const Color(0xFFE5E7EB),
                        width: 1,
                      ),
                    ),
                    child: TextField(
                      controller: _searchController,
                      onChanged: (v) => setState(() => _searchQuery = v),
                      style: GoogleFonts.ibmPlexSans(fontSize: 13),
                      decoration: InputDecoration(
                        hintText: 'Search documents…',
                        hintStyle: GoogleFonts.ibmPlexSans(
                          fontSize: 13,
                          color: AppTheme.muted,
                        ),
                        prefixIcon: const Icon(
                          Icons.search_rounded,
                          size: 18,
                          color: AppTheme.muted,
                        ),
                        suffixIcon: _searchQuery.isNotEmpty
                            ? IconButton(
                                icon: const Icon(
                                  Icons.clear_rounded,
                                  size: 16,
                                  color: AppTheme.muted,
                                ),
                                onPressed: () {
                                  _searchController.clear();
                                  setState(() => _searchQuery = '');
                                },
                              )
                            : null,
                        border: InputBorder.none,
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 12,
                        ),
                        filled: false,
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  // Category filter chips
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: _categories.map((cat) {
                        final isSelected = _filterCategory == cat;
                        return Padding(
                          padding: const EdgeInsets.only(right: 8),
                          child: GestureDetector(
                            onTap: () => setState(() => _filterCategory = cat),
                            child: AnimatedContainer(
                              duration: const Duration(milliseconds: 180),
                              padding: const EdgeInsets.symmetric(
                                horizontal: 12,
                                vertical: 6,
                              ),
                              decoration: BoxDecoration(
                                color: isSelected
                                    ? AppTheme.primary
                                    : AppTheme.surface,
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(
                                  color: isSelected
                                      ? AppTheme.primary
                                      : const Color(0xFFE5E7EB),
                                  width: 1,
                                ),
                              ),
                              child: Text(
                                cat,
                                style: GoogleFonts.ibmPlexSans(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w500,
                                  color: isSelected
                                      ? Colors.white
                                      : AppTheme.muted,
                                ),
                              ),
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    '${filtered.length} document${filtered.length != 1 ? 's' : ''}',
                    style: GoogleFonts.ibmPlexSans(
                      fontSize: 12,
                      color: AppTheme.muted,
                    ),
                  ),
                ],
              ),
            ),
          ),
          if (filtered.isEmpty)
            SliverFillRemaining(
              child: EmptyStateWidget(
                icon: Icons.folder_open_outlined,
                title: 'No documents found',
                description:
                    'No documents match your search or filter. Try a different category or upload a new document.',
                actionLabel: 'Upload Document',
                onAction: () {},
              ),
            )
          else
            SliverList(
              delegate: SliverChildBuilderDelegate((context, index) {
                final doc = filtered[index];
                final isLast = index == filtered.length - 1;
                return Padding(
                  padding: EdgeInsets.fromLTRB(16, index == 0 ? 10 : 0, 16, 0),
                  child: _buildDocumentCard(doc, index, isLast),
                );
              }, childCount: filtered.length),
            ),
          const SliverToBoxAdapter(child: SizedBox(height: 100)),
        ],
      ),
    );
  }

  Widget _buildDocumentCard(Map<String, dynamic> doc, int index, bool isLast) {
    final type = doc['type'] as String;
    final status = doc['status'] as String;
    final isPendingReview = status == 'pending_review';
    final typeColor = _typeColor(type);

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: AppTheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isPendingReview
              ? AppTheme.warning.withAlpha(89)
              : const Color(0xFFE5E7EB),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha(10),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: InkWell(
        onTap: () {},
        borderRadius: BorderRadius.circular(12),
        splashColor: AppTheme.primary.withAlpha(13),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // File type icon
              Container(
                width: 44,
                height: 52,
                decoration: BoxDecoration(
                  color: typeColor.withAlpha(26),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: typeColor.withAlpha(64), width: 1),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      type == 'DWG'
                          ? Icons.architecture_rounded
                          : type == 'IFC'
                          ? Icons.view_in_ar_rounded
                          : Icons.picture_as_pdf_rounded,
                      size: 20,
                      color: typeColor,
                    ),
                    const SizedBox(height: 2),
                    Text(
                      type,
                      style: GoogleFonts.ibmPlexMono(
                        fontSize: 9,
                        fontWeight: FontWeight.w700,
                        color: typeColor,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 12),
              // Content
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          child: Text(
                            doc['name'] as String,
                            style: GoogleFonts.ibmPlexSans(
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                              color: AppTheme.onSurface,
                              height: 1.3,
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        if (isPendingReview)
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 6,
                              vertical: 2,
                            ),
                            decoration: BoxDecoration(
                              color: AppTheme.warningContainer,
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: Text(
                              'Review',
                              style: GoogleFonts.ibmPlexSans(
                                fontSize: 10,
                                fontWeight: FontWeight.w600,
                                color: AppTheme.warning,
                              ),
                            ),
                          ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Wrap(
                      spacing: 8,
                      runSpacing: 4,
                      children: [
                        _buildMeta(
                          Icons.folder_outlined,
                          doc['category'] as String,
                        ),
                        _buildMeta(
                          Icons.history_rounded,
                          doc['version'] as String,
                        ),
                        _buildMeta(
                          Icons.storage_outlined,
                          doc['fileSize'] as String,
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Row(
                      children: [
                        Icon(
                          Icons.person_outline_rounded,
                          size: 11,
                          color: AppTheme.muted,
                        ),
                        const SizedBox(width: 3),
                        Text(
                          doc['uploadedBy'] as String,
                          style: GoogleFonts.ibmPlexSans(
                            fontSize: 11,
                            color: AppTheme.muted,
                          ),
                        ),
                        const SizedBox(width: 8),
                        Icon(
                          Icons.upload_outlined,
                          size: 11,
                          color: AppTheme.muted,
                        ),
                        const SizedBox(width: 3),
                        Text(
                          doc['uploadDate'] as String,
                          style: GoogleFonts.ibmPlexSans(
                            fontSize: 11,
                            color: AppTheme.muted,
                          ),
                        ),
                        const Spacer(),
                        // Action buttons
                        _buildIconAction(Icons.download_outlined, () {}),
                        const SizedBox(width: 4),
                        _buildIconAction(Icons.share_outlined, () {}),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildMeta(IconData icon, String label) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 10, color: AppTheme.muted),
        const SizedBox(width: 3),
        Text(
          label,
          style: GoogleFonts.ibmPlexSans(fontSize: 10, color: AppTheme.muted),
        ),
      ],
    );
  }

  Widget _buildIconAction(IconData icon, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(6),
      child: Container(
        padding: const EdgeInsets.all(6),
        decoration: BoxDecoration(
          color: AppTheme.surfaceVariant,
          borderRadius: BorderRadius.circular(6),
        ),
        child: Icon(icon, size: 14, color: AppTheme.primary),
      ),
    );
  }
}
