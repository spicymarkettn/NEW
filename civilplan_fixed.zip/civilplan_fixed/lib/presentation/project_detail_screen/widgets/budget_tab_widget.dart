import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:fl_chart/fl_chart.dart';
import '../../../theme/app_theme.dart';

class BudgetTabWidget extends StatefulWidget {
  final Map<String, dynamic> project;

  const BudgetTabWidget({super.key, required this.project});

  @override
  State<BudgetTabWidget> createState() => _BudgetTabWidgetState();
}

class _BudgetTabWidgetState extends State<BudgetTabWidget> {
  int _touchedPieIndex = -1;

  // TODO: Replace with actual budget data from repository in production
  static final List<Map<String, dynamic>> _categoryMaps = [
    {
      'category': 'Earthworks & Grading',
      'budgeted': 2400000,
      'actual': 2510000,
      'color': 0xFF1A56A0,
    },
    {
      'category': 'Drainage Infrastructure',
      'budgeted': 3200000,
      'actual': 3840000,
      'color': 0xFFB91C1C,
    },
    {
      'category': 'Pavement Base Course',
      'budgeted': 4100000,
      'actual': 3890000,
      'color': 0xFF0D7B5E,
    },
    {
      'category': 'Bridge Works',
      'budgeted': 1800000,
      'actual': 1920000,
      'color': 0xFFB45309,
    },
    {
      'category': 'Site Administration',
      'budgeted': 680000,
      'actual': 740000,
      'color': 0xFF6D4C9E,
    },
    {
      'category': 'Contingency Reserve',
      'budgeted': 620000,
      'actual': 540000,
      'color': 0xFF6B7280,
    },
  ];

  static final List<Map<String, dynamic>> _changeOrderMaps = [
    {
      'ref': 'CO-007',
      'description': 'Additional culverts — revised drainage design',
      'amount': 420000,
      'status': 'approved',
      'date': 'Mar 12, 2026',
    },
    {
      'ref': 'CO-008',
      'description': 'Concrete price escalation — Q1 2026',
      'amount': 185000,
      'status': 'approved',
      'date': 'Mar 28, 2026',
    },
    {
      'ref': 'CO-009',
      'description': 'Scope extension — additional 1.2km shoulder widening',
      'amount': 620000,
      'status': 'pending',
      'date': 'Apr 14, 2026',
    },
    {
      'ref': 'CO-010',
      'description': 'Traffic management extension — 8 additional weeks',
      'amount': 96000,
      'status': 'pending',
      'date': 'Apr 22, 2026',
    },
  ];

  String _formatCurrency(double amount) {
    if (amount >= 1000000) {
      return '\$${(amount / 1000000).toStringAsFixed(2)}M';
    } else if (amount >= 1000) {
      return '\$${(amount / 1000).toStringAsFixed(0)}K';
    }
    return '\$${amount.toStringAsFixed(0)}';
  }

  @override
  Widget build(BuildContext context) {
    final budgetTotal = (widget.project['budgetTotal'] as int).toDouble();
    final budgetSpent = (widget.project['budgetSpent'] as int).toDouble();
    final budgetPct = widget.project['budgetPercent'] as int;
    final isOverBudget = budgetPct > 100;
    final variance = budgetSpent - budgetTotal;

    return Builder(
      builder: (context) => CustomScrollView(
        slivers: [
          SliverOverlapInjector(
            handle: NestedScrollView.sliverOverlapAbsorberHandleFor(context),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Budget summary header
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: isOverBudget
                          ? AppTheme.errorContainer
                          : AppTheme.secondaryContainer,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: isOverBudget
                            ? AppTheme.errorColor.withAlpha(77)
                            : AppTheme.secondary.withAlpha(77),
                        width: 1,
                      ),
                    ),
                    child: Column(
                      children: [
                        Row(
                          children: [
                            Icon(
                              isOverBudget
                                  ? Icons.warning_amber_rounded
                                  : Icons.account_balance_wallet_outlined,
                              size: 18,
                              color: isOverBudget
                                  ? AppTheme.errorColor
                                  : AppTheme.secondary,
                            ),
                            const SizedBox(width: 8),
                            Text(
                              isOverBudget
                                  ? 'Budget Overrun Detected'
                                  : 'Budget Status',
                              style: GoogleFonts.ibmPlexSans(
                                fontSize: 13,
                                fontWeight: FontWeight.w600,
                                color: isOverBudget
                                    ? AppTheme.errorColor
                                    : AppTheme.secondary,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 14),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            _buildBudgetStat(
                              'Contract Value',
                              _formatCurrency(budgetTotal),
                              AppTheme.onSurface,
                            ),
                            Container(
                              width: 1,
                              height: 40,
                              color: const Color(0xFFD1D5DB),
                            ),
                            _buildBudgetStat(
                              'Total Spent',
                              _formatCurrency(budgetSpent),
                              isOverBudget
                                  ? AppTheme.errorColor
                                  : AppTheme.secondary,
                            ),
                            Container(
                              width: 1,
                              height: 40,
                              color: const Color(0xFFD1D5DB),
                            ),
                            _buildBudgetStat(
                              'Variance',
                              (variance > 0 ? '+' : '') +
                                  _formatCurrency(variance),
                              isOverBudget
                                  ? AppTheme.errorColor
                                  : AppTheme.secondary,
                            ),
                          ],
                        ),
                        const SizedBox(height: 14),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  'Budget Utilization',
                                  style: GoogleFonts.ibmPlexSans(
                                    fontSize: 12,
                                    color: AppTheme.onSurface,
                                  ),
                                ),
                                Text(
                                  '$budgetPct%',
                                  style: GoogleFonts.ibmPlexMono(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w700,
                                    color: isOverBudget
                                        ? AppTheme.errorColor
                                        : AppTheme.secondary,
                                    fontFeatures: const [
                                      FontFeature.tabularFigures(),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 6),
                            ClipRRect(
                              borderRadius: BorderRadius.circular(4),
                              child: LinearProgressIndicator(
                                value: (budgetPct / 100.0).clamp(0.0, 1.0),
                                minHeight: 8,
                                backgroundColor: Colors.white.withAlpha(128),
                                valueColor: AlwaysStoppedAnimation<Color>(
                                  isOverBudget
                                      ? AppTheme.errorColor
                                      : AppTheme.secondary,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),
                  // Pie chart + breakdown
                  _buildSectionTitle('Cost Category Breakdown'),
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: AppTheme.surface,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: const Color(0xFFE5E7EB),
                        width: 1,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withAlpha(10),
                          blurRadius: 8,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: Column(
                      children: [
                        SizedBox(
                          height: 200,
                          child: Row(
                            children: [
                              Expanded(
                                flex: 5,
                                child: PieChart(
                                  PieChartData(
                                    pieTouchData: PieTouchData(
                                      touchCallback: (event, response) {
                                        setState(() {
                                          if (response?.touchedSection !=
                                                  null &&
                                              event is! FlPointerExitEvent) {
                                            _touchedPieIndex = response!
                                                .touchedSection!
                                                .touchedSectionIndex;
                                          } else {
                                            _touchedPieIndex = -1;
                                          }
                                        });
                                      },
                                    ),
                                    sectionsSpace: 2,
                                    centerSpaceRadius: 50,
                                    sections: List.generate(
                                      _categoryMaps.length,
                                      (i) {
                                        final cat = _categoryMaps[i];
                                        final isTouched = i == _touchedPieIndex;
                                        final actual = (cat['actual'] as int)
                                            .toDouble();
                                        final total = _categoryMaps
                                            .fold<double>(
                                              0,
                                              (sum, c) =>
                                                  sum +
                                                  (c['actual'] as int)
                                                      .toDouble(),
                                            );
                                        return PieChartSectionData(
                                          color: Color(cat['color'] as int),
                                          value: actual,
                                          title: isTouched
                                              ? '${(actual / total * 100).toStringAsFixed(0)}%'
                                              : '',
                                          radius: isTouched ? 55 : 48,
                                          titleStyle: GoogleFonts.ibmPlexMono(
                                            fontSize: 11,
                                            fontWeight: FontWeight.w700,
                                            color: Colors.white,
                                          ),
                                        );
                                      },
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                flex: 5,
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: List.generate(
                                    _categoryMaps.length,
                                    (i) {
                                      final cat = _categoryMaps[i];
                                      return Padding(
                                        padding: const EdgeInsets.only(
                                          bottom: 6,
                                        ),
                                        child: Row(
                                          children: [
                                            Container(
                                              width: 10,
                                              height: 10,
                                              decoration: BoxDecoration(
                                                color: Color(
                                                  cat['color'] as int,
                                                ),
                                                borderRadius:
                                                    BorderRadius.circular(2),
                                              ),
                                            ),
                                            const SizedBox(width: 6),
                                            Expanded(
                                              child: Text(
                                                cat['category'] as String,
                                                style: GoogleFonts.ibmPlexSans(
                                                  fontSize: 10,
                                                  color: AppTheme.onSurface,
                                                ),
                                                maxLines: 2,
                                                overflow: TextOverflow.ellipsis,
                                              ),
                                            ),
                                          ],
                                        ),
                                      );
                                    },
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 16),
                        const Divider(color: Color(0xFFE5E7EB), height: 1),
                        const SizedBox(height: 12),
                        // Category rows
                        ...List.generate(_categoryMaps.length, (i) {
                          final cat = _categoryMaps[i];
                          final budgeted = (cat['budgeted'] as int).toDouble();
                          final actual = (cat['actual'] as int).toDouble();
                          final isOver = actual > budgeted;
                          final pct = (actual / budgeted * 100).round();
                          return Padding(
                            padding: const EdgeInsets.only(bottom: 10),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Container(
                                      width: 8,
                                      height: 8,
                                      decoration: BoxDecoration(
                                        color: Color(cat['color'] as int),
                                        borderRadius: BorderRadius.circular(2),
                                      ),
                                    ),
                                    const SizedBox(width: 8),
                                    Expanded(
                                      child: Text(
                                        cat['category'] as String,
                                        style: GoogleFonts.ibmPlexSans(
                                          fontSize: 12,
                                          fontWeight: FontWeight.w500,
                                          color: AppTheme.onSurface,
                                        ),
                                      ),
                                    ),
                                    Text(
                                      _formatCurrency(actual),
                                      style: GoogleFonts.ibmPlexMono(
                                        fontSize: 12,
                                        fontWeight: FontWeight.w600,
                                        color: isOver
                                            ? AppTheme.errorColor
                                            : AppTheme.onSurface,
                                        fontFeatures: const [
                                          FontFeature.tabularFigures(),
                                        ],
                                      ),
                                    ),
                                    const SizedBox(width: 6),
                                    Container(
                                      padding: const EdgeInsets.symmetric(
                                        horizontal: 5,
                                        vertical: 2,
                                      ),
                                      decoration: BoxDecoration(
                                        color: isOver
                                            ? AppTheme.errorContainer
                                            : AppTheme.secondaryContainer,
                                        borderRadius: BorderRadius.circular(4),
                                      ),
                                      child: Text(
                                        '$pct%',
                                        style: GoogleFonts.ibmPlexMono(
                                          fontSize: 10,
                                          fontWeight: FontWeight.w600,
                                          color: isOver
                                              ? AppTheme.errorColor
                                              : AppTheme.secondary,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 5),
                                Stack(
                                  children: [
                                    Container(
                                      height: 4,
                                      decoration: BoxDecoration(
                                        color: const Color(0xFFE5E7EB),
                                        borderRadius: BorderRadius.circular(3),
                                      ),
                                    ),
                                    FractionallySizedBox(
                                      widthFactor: (actual / budgeted).clamp(
                                        0.0,
                                        1.0,
                                      ),
                                      child: Container(
                                        height: 4,
                                        decoration: BoxDecoration(
                                          color: Color(cat['color'] as int),
                                          borderRadius: BorderRadius.circular(
                                            3,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 2),
                                Text(
                                  'Budget: ${_formatCurrency(budgeted)}',
                                  style: GoogleFonts.ibmPlexSans(
                                    fontSize: 10,
                                    color: AppTheme.muted,
                                  ),
                                ),
                              ],
                            ),
                          );
                        }),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),
                  // Change orders
                  _buildSectionTitle('Change Orders'),
                  const SizedBox(height: 12),
                  Container(
                    decoration: BoxDecoration(
                      color: AppTheme.surface,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: const Color(0xFFE5E7EB),
                        width: 1,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withAlpha(10),
                          blurRadius: 8,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: Column(
                      children: List.generate(
                        _changeOrderMaps.length,
                        (i) => _buildChangeOrderRow(
                          _changeOrderMaps[i],
                          i == _changeOrderMaps.length - 1,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 100),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildChangeOrderRow(Map<String, dynamic> co, bool isLast) {
    final isApproved = co['status'] == 'approved';
    return Container(
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
      decoration: BoxDecoration(
        border: isLast
            ? null
            : const Border(
                bottom: BorderSide(color: Color(0xFFF3F4F6), width: 1),
              ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
            decoration: BoxDecoration(
              color: AppTheme.primaryContainer,
              borderRadius: BorderRadius.circular(5),
            ),
            child: Text(
              co['ref'] as String,
              style: GoogleFonts.ibmPlexMono(
                fontSize: 10,
                fontWeight: FontWeight.w600,
                color: AppTheme.primary,
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  co['description'] as String,
                  style: GoogleFonts.ibmPlexSans(
                    fontSize: 13,
                    color: AppTheme.onSurface,
                    height: 1.4,
                  ),
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    Text(
                      co['date'] as String,
                      style: GoogleFonts.ibmPlexSans(
                        fontSize: 11,
                        color: AppTheme.muted,
                      ),
                    ),
                    const Spacer(),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 6,
                        vertical: 2,
                      ),
                      decoration: BoxDecoration(
                        color: isApproved
                            ? AppTheme.secondaryContainer
                            : AppTheme.warningContainer,
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Text(
                        isApproved ? 'Approved' : 'Pending',
                        style: GoogleFonts.ibmPlexSans(
                          fontSize: 10,
                          fontWeight: FontWeight.w600,
                          color: isApproved
                              ? AppTheme.secondary
                              : AppTheme.warning,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(width: 10),
          Text(
            '+${_formatCurrency((co['amount'] as int).toDouble())}',
            style: GoogleFonts.ibmPlexMono(
              fontSize: 13,
              fontWeight: FontWeight.w700,
              color: AppTheme.warning,
              fontFeatures: const [FontFeature.tabularFigures()],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBudgetStat(String label, String value, Color valueColor) {
    return Column(
      children: [
        Text(
          label,
          style: GoogleFonts.ibmPlexSans(fontSize: 10, color: AppTheme.muted),
        ),
        const SizedBox(height: 4),
        Text(
          value,
          style: GoogleFonts.ibmPlexMono(
            fontSize: 16,
            fontWeight: FontWeight.w700,
            color: valueColor,
            fontFeatures: const [FontFeature.tabularFigures()],
          ),
        ),
      ],
    );
  }

  Widget _buildSectionTitle(String title) {
    return Text(
      title,
      style: GoogleFonts.ibmPlexSans(
        fontSize: 15,
        fontWeight: FontWeight.w700,
        color: AppTheme.onSurface,
      ),
    );
  }
}
