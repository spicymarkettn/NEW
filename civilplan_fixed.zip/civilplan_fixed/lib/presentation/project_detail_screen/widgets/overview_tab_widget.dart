import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:fl_chart/fl_chart.dart';
import '../../../theme/app_theme.dart';

class OverviewTabWidget extends StatefulWidget {
  final Map<String, dynamic> project;

  const OverviewTabWidget({super.key, required this.project});

  @override
  State<OverviewTabWidget> createState() => _OverviewTabWidgetState();
}

class _OverviewTabWidgetState extends State<OverviewTabWidget> {
  // TODO: Replace with actual data from repository in production
  // Weekly task completion data (last 8 weeks)
  final List<_WeeklyCompletion> _weeklyData = [
    _WeeklyCompletion(week: 'W18', completed: 8, total: 14),
    _WeeklyCompletion(week: 'W19', completed: 11, total: 15),
    _WeeklyCompletion(week: 'W20', completed: 6, total: 16),
    _WeeklyCompletion(week: 'W21', completed: 13, total: 18),
    _WeeklyCompletion(week: 'W22', completed: 9, total: 17),
    _WeeklyCompletion(week: 'W23', completed: 7, total: 19),
    _WeeklyCompletion(week: 'W24', completed: 14, total: 20),
    _WeeklyCompletion(week: 'W25', completed: 10, total: 22),
  ];

  static final List<Map<String, dynamic>> _milestoneMaps = [
    {
      'name': 'Site Clearance & Mobilization',
      'dueDate': 'Apr 30, 2025',
      'status': 'completed',
      'completion': 100,
    },
    {
      'name': 'Earthworks & Grading',
      'dueDate': 'Jul 15, 2025',
      'status': 'completed',
      'completion': 100,
    },
    {
      'name': 'Drainage Infrastructure',
      'dueDate': 'Sep 30, 2025',
      'status': 'inProgress',
      'completion': 68,
    },
    {
      'name': 'Pavement Base Course',
      'dueDate': 'Nov 20, 2025',
      'status': 'inProgress',
      'completion': 31,
    },
    {
      'name': 'Sangotedo Bridge Widening',
      'dueDate': 'Jan 15, 2026',
      'status': 'pending',
      'completion': 0,
    },
    {
      'name': 'Ajah Interchange Construction',
      'dueDate': 'Jun 30, 2026',
      'status': 'pending',
      'completion': 0,
    },
    {
      'name': 'Road Markings & Signage',
      'dueDate': 'Nov 01, 2026',
      'status': 'pending',
      'completion': 0,
    },
    {
      'name': 'Final Inspection & Handover',
      'dueDate': 'Dec 30, 2026',
      'status': 'pending',
      'completion': 0,
    },
  ];

  static final List<Map<String, dynamic>> _activityMaps = [
    {
      'type': 'task_completed',
      'description': 'Drainage pipe installation at Ch.12+400 completed',
      'user': 'Chidi Eze',
      'time': '2h ago',
      'icon': 'task_alt',
    },
    {
      'type': 'document_uploaded',
      'description': 'Updated ITP for concrete works uploaded',
      'user': 'Amara Nwosu',
      'time': '4h ago',
      'icon': 'upload_file',
    },
    {
      'type': 'budget_alert',
      'description': 'Budget utilization exceeded 100% — review required',
      'user': 'System',
      'time': '6h ago',
      'icon': 'warning',
    },
    {
      'type': 'task_blocked',
      'description': 'Concrete delivery delayed — bridge works blocked',
      'user': 'Fatima Al-Rashid',
      'time': '1d ago',
      'icon': 'block',
    },
    {
      'type': 'report_submitted',
      'description': 'Weekly progress report W24 submitted for review',
      'user': 'Remi Okonkwo',
      'time': '2d ago',
      'icon': 'summarize',
    },
  ];

  @override
  Widget build(BuildContext context) {
    final project = widget.project;
    final daysRemaining = project['daysRemaining'] as int;
    final schedPct = project['schedulePercent'] as int;
    final openTasks = project['openTasks'] as int;
    final isDelayed = daysRemaining < 0;

    return Builder(
      builder: (context) => CustomScrollView(
        slivers: [
          SliverOverlapInjector(
            handle: NestedScrollView.sliverOverlapAbsorberHandleFor(context),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Project description
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: AppTheme.surface,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: const Color(0xFFE5E7EB),
                        width: 1,
                      ),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Project Overview',
                          style: GoogleFonts.ibmPlexSans(
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                            color: AppTheme.onSurface,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          project['description'] as String? ??
                              'No description available.',
                          style: GoogleFonts.ibmPlexSans(
                            fontSize: 13,
                            color: AppTheme.muted,
                            height: 1.5,
                          ),
                        ),
                        const SizedBox(height: 10),
                        Row(
                          children: [
                            _buildInfoPair(
                              Icons.calendar_today_outlined,
                              'Start',
                              project['startDate'] as String? ?? 'N/A',
                            ),
                            const SizedBox(width: 20),
                            _buildInfoPair(
                              Icons.flag_outlined,
                              'End',
                              project['endDate'] as String? ?? 'N/A',
                            ),
                            const SizedBox(width: 20),
                            _buildInfoPair(
                              Icons.engineering_outlined,
                              'Engineer',
                              project['engineer'] as String? ?? 'N/A',
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  // KPI chips row
                  Row(
                    children: [
                      Expanded(
                        child: _buildKpiChip(
                          label: isDelayed ? 'Days Overdue' : 'Days Left',
                          value: isDelayed
                              ? '${daysRemaining.abs()}'
                              : '$daysRemaining',
                          icon: Icons.schedule_rounded,
                          color: isDelayed
                              ? AppTheme.errorColor
                              : AppTheme.secondary,
                          bgColor: isDelayed
                              ? AppTheme.errorContainer
                              : AppTheme.secondaryContainer,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: _buildKpiChip(
                          label: 'Completion',
                          value: '$schedPct%',
                          icon: Icons.pie_chart_outline_rounded,
                          color: AppTheme.primary,
                          bgColor: AppTheme.primaryContainer,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: _buildKpiChip(
                          label: 'Open Tasks',
                          value: '$openTasks',
                          icon: Icons.checklist_rounded,
                          color: openTasks > 20
                              ? AppTheme.warning
                              : AppTheme.onSurface,
                          bgColor: openTasks > 20
                              ? AppTheme.warningContainer
                              : AppTheme.surfaceVariant,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  // Task completion trend chart
                  _buildSectionTitle('Weekly Task Completion'),
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.fromLTRB(14, 16, 14, 8),
                    decoration: BoxDecoration(
                      color: AppTheme.surface,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: const Color(0xFFE5E7EB),
                        width: 1,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withAlpha(10),
                          blurRadius: 8,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            _buildLegendDot(AppTheme.primary, 'Completed'),
                            const SizedBox(width: 12),
                            _buildLegendDot(
                              const Color(0xFFE5E7EB),
                              'Total Assigned',
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        SizedBox(
                          height: 160,
                          child: LineChart(
                            LineChartData(
                              minY: 0,
                              maxY: 25,
                              lineTouchData: LineTouchData(
                                touchTooltipData: LineTouchTooltipData(
                                  tooltipRoundedRadius: 8,
                                  getTooltipItems: (spots) {
                                    return spots.map((spot) {
                                      final idx = spot.x.toInt();
                                      final entry = _weeklyData[idx];
                                      final isCompleted = spot.barIndex == 0;
                                      return LineTooltipItem(
                                        isCompleted
                                            ? '${entry.completed} done'
                                            : '${entry.total} assigned',
                                        GoogleFonts.ibmPlexMono(
                                          fontSize: 11,
                                          fontWeight: FontWeight.w600,
                                          color: Colors.white,
                                        ),
                                      );
                                    }).toList();
                                  },
                                ),
                              ),
                              gridData: FlGridData(
                                drawVerticalLine: false,
                                horizontalInterval: 5,
                                getDrawingHorizontalLine: (_) => FlLine(
                                  color: const Color(0xFFE5E7EB),
                                  strokeWidth: 1,
                                  dashArray: [4, 4],
                                ),
                              ),
                              borderData: FlBorderData(show: false),
                              titlesData: FlTitlesData(
                                bottomTitles: AxisTitles(
                                  sideTitles: SideTitles(
                                    showTitles: true,
                                    reservedSize: 24,
                                    getTitlesWidget: (value, meta) {
                                      final idx = value.toInt();
                                      if (idx < 0 ||
                                          idx >= _weeklyData.length) {
                                        return const SizedBox.shrink();
                                      }
                                      return Text(
                                        _weeklyData[idx].week,
                                        style: GoogleFonts.ibmPlexSans(
                                          fontSize: 10,
                                          color: AppTheme.muted,
                                        ),
                                      );
                                    },
                                  ),
                                ),
                                leftTitles: AxisTitles(
                                  sideTitles: SideTitles(
                                    showTitles: true,
                                    reservedSize: 28,
                                    interval: 5,
                                    getTitlesWidget: (value, meta) => Text(
                                      value.toInt().toString(),
                                      style: GoogleFonts.ibmPlexMono(
                                        fontSize: 9,
                                        color: AppTheme.muted,
                                      ),
                                    ),
                                  ),
                                ),
                                topTitles: const AxisTitles(
                                  sideTitles: SideTitles(showTitles: false),
                                ),
                                rightTitles: const AxisTitles(
                                  sideTitles: SideTitles(showTitles: false),
                                ),
                              ),
                              lineBarsData: [
                                // Completed line
                                LineChartBarData(
                                  spots: List.generate(
                                    _weeklyData.length,
                                    (i) => FlSpot(
                                      i.toDouble(),
                                      _weeklyData[i].completed.toDouble(),
                                    ),
                                  ),
                                  color: AppTheme.primary,
                                  barWidth: 2.5,
                                  isCurved: true,
                                  curveSmoothness: 0.3,
                                  dotData: FlDotData(
                                    show: true,
                                    getDotPainter: (spot, pct, bar, idx) =>
                                        FlDotCirclePainter(
                                          radius: 3,
                                          color: AppTheme.primary,
                                          strokeWidth: 1.5,
                                          strokeColor: AppTheme.surface,
                                        ),
                                  ),
                                  belowBarData: BarAreaData(
                                    show: true,
                                    gradient: LinearGradient(
                                      colors: [
                                        AppTheme.primary.withAlpha(46),
                                        AppTheme.primary.withAlpha(0),
                                      ],
                                      begin: Alignment.topCenter,
                                      end: Alignment.bottomCenter,
                                    ),
                                  ),
                                ),
                                // Total assigned line
                                LineChartBarData(
                                  spots: List.generate(
                                    _weeklyData.length,
                                    (i) => FlSpot(
                                      i.toDouble(),
                                      _weeklyData[i].total.toDouble(),
                                    ),
                                  ),
                                  color: const Color(0xFFD1D5DB),
                                  barWidth: 1.5,
                                  isCurved: true,
                                  curveSmoothness: 0.3,
                                  dotData: const FlDotData(show: false),
                                  dashArray: [4, 4],
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),
                  // Milestones
                  _buildSectionTitle('Project Milestones'),
                  const SizedBox(height: 12),
                  Container(
                    decoration: BoxDecoration(
                      color: AppTheme.surface,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: const Color(0xFFE5E7EB),
                        width: 1,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withAlpha(10),
                          blurRadius: 8,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: Column(
                      children: List.generate(
                        _milestoneMaps.length,
                        (i) => _buildMilestoneRow(
                          _milestoneMaps[i],
                          i,
                          _milestoneMaps.length,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  // Recent activity
                  _buildSectionTitle('Recent Activity'),
                  const SizedBox(height: 12),
                  Container(
                    decoration: BoxDecoration(
                      color: AppTheme.surface,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: const Color(0xFFE5E7EB),
                        width: 1,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withAlpha(10),
                          blurRadius: 8,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: Column(
                      children: List.generate(
                        _activityMaps.length,
                        (i) => _buildActivityRow(
                          _activityMaps[i],
                          i,
                          _activityMaps.length,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 100),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildKpiChip({
    required String label,
    required String value,
    required IconData icon,
    required Color color,
    required Color bgColor,
  }) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 16, color: color),
          const SizedBox(height: 6),
          Text(
            value,
            style: GoogleFonts.ibmPlexMono(
              fontSize: 20,
              fontWeight: FontWeight.w700,
              color: color,
              fontFeatures: const [FontFeature.tabularFigures()],
            ),
          ),
          Text(
            label,
            style: GoogleFonts.ibmPlexSans(
              fontSize: 10,
              color: color.withAlpha(204),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMilestoneRow(
    Map<String, dynamic> milestone,
    int index,
    int total,
  ) {
    final status = milestone['status'] as String;
    final completion = milestone['completion'] as int;
    final isCompleted = status == 'completed';
    final isInProgress = status == 'inProgress';
    final isLast = index == total - 1;

    Color nodeColor;
    IconData nodeIcon;
    if (isCompleted) {
      nodeColor = AppTheme.secondary;
      nodeIcon = Icons.check_circle_rounded;
    } else if (isInProgress) {
      nodeColor = AppTheme.primary;
      nodeIcon = Icons.radio_button_checked_rounded;
    } else {
      nodeColor = const Color(0xFFD1D5DB);
      nodeIcon = Icons.radio_button_unchecked_rounded;
    }

    return IntrinsicHeight(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Timeline column
          Padding(
            padding: const EdgeInsets.only(left: 16),
            child: Column(
              children: [
                const SizedBox(height: 16),
                Icon(nodeIcon, size: 18, color: nodeColor),
                if (!isLast)
                  Expanded(
                    child: Container(
                      width: 2,
                      color: isCompleted
                          ? AppTheme.secondary.withAlpha(77)
                          : const Color(0xFFE5E7EB),
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          // Content
          Expanded(
            child: Padding(
              padding: EdgeInsets.only(
                top: 12,
                bottom: isLast ? 16 : 12,
                right: 16,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: Text(
                          milestone['name'] as String,
                          style: GoogleFonts.ibmPlexSans(
                            fontSize: 13,
                            fontWeight: isInProgress
                                ? FontWeight.w600
                                : FontWeight.w500,
                            color: isCompleted
                                ? AppTheme.muted
                                : AppTheme.onSurface,
                          ),
                        ),
                      ),
                      Text(
                        milestone['dueDate'] as String,
                        style: GoogleFonts.ibmPlexSans(
                          fontSize: 10,
                          color: AppTheme.muted,
                        ),
                      ),
                    ],
                  ),
                  if (isInProgress) ...[
                    const SizedBox(height: 6),
                    Row(
                      children: [
                        Expanded(
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(3),
                            child: LinearProgressIndicator(
                              value: completion / 100.0,
                              minHeight: 4,
                              backgroundColor: const Color(0xFFE5E7EB),
                              valueColor: const AlwaysStoppedAnimation<Color>(
                                AppTheme.primary,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          '$completion%',
                          style: GoogleFonts.ibmPlexMono(
                            fontSize: 10,
                            color: AppTheme.primary,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ],
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActivityRow(
    Map<String, dynamic> activity,
    int index,
    int total,
  ) {
    final type = activity['type'] as String;
    final isLast = index == total - 1;

    Color iconColor;
    Color iconBg;
    IconData icon;

    switch (type) {
      case 'task_completed':
        iconColor = AppTheme.secondary;
        iconBg = AppTheme.secondaryContainer;
        icon = Icons.task_alt_rounded;
        break;
      case 'document_uploaded':
        iconColor = AppTheme.primary;
        iconBg = AppTheme.primaryContainer;
        icon = Icons.upload_file_rounded;
        break;
      case 'budget_alert':
        iconColor = AppTheme.errorColor;
        iconBg = AppTheme.errorContainer;
        icon = Icons.warning_amber_rounded;
        break;
      case 'task_blocked':
        iconColor = AppTheme.warning;
        iconBg = AppTheme.warningContainer;
        icon = Icons.block_rounded;
        break;
      default:
        iconColor = AppTheme.muted;
        iconBg = AppTheme.surfaceVariant;
        icon = Icons.summarize_outlined;
    }

    return Container(
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
      decoration: BoxDecoration(
        border: isLast
            ? null
            : const Border(
                bottom: BorderSide(color: Color(0xFFF3F4F6), width: 1),
              ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              color: iconBg,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, size: 16, color: iconColor),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  activity['description'] as String,
                  style: GoogleFonts.ibmPlexSans(
                    fontSize: 13,
                    color: AppTheme.onSurface,
                    height: 1.4,
                  ),
                ),
                const SizedBox(height: 3),
                Row(
                  children: [
                    Text(
                      activity['user'] as String,
                      style: GoogleFonts.ibmPlexSans(
                        fontSize: 11,
                        color: AppTheme.primary,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    Text(
                      ' · ${activity['time']}',
                      style: GoogleFonts.ibmPlexSans(
                        fontSize: 11,
                        color: AppTheme.muted,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoPair(IconData icon, String label, String value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(icon, size: 11, color: AppTheme.muted),
            const SizedBox(width: 4),
            Text(
              label,
              style: GoogleFonts.ibmPlexSans(
                fontSize: 10,
                color: AppTheme.muted,
              ),
            ),
          ],
        ),
        const SizedBox(height: 2),
        Text(
          value,
          style: GoogleFonts.ibmPlexSans(
            fontSize: 12,
            fontWeight: FontWeight.w600,
            color: AppTheme.onSurface,
          ),
        ),
      ],
    );
  }

  Widget _buildSectionTitle(String title) {
    return Text(
      title,
      style: GoogleFonts.ibmPlexSans(
        fontSize: 15,
        fontWeight: FontWeight.w700,
        color: AppTheme.onSurface,
      ),
    );
  }

  Widget _buildLegendDot(Color color, String label) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 10,
          height: 10,
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        const SizedBox(width: 4),
        Text(
          label,
          style: GoogleFonts.ibmPlexSans(fontSize: 10, color: AppTheme.muted),
        ),
      ],
    );
  }
}

class _WeeklyCompletion {
  final String week;
  final int completed;
  final int total;
  const _WeeklyCompletion({
    required this.week,
    required this.completed,
    required this.total,
  });
}
