import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../widgets/status_badge_widget.dart';

class ProjectDetailHeaderWidget extends StatelessWidget {
  final Map<String, dynamic> project;
  final ProjectStatus status;

  const ProjectDetailHeaderWidget({
    super.key,
    required this.project,
    required this.status,
  });

  @override
  Widget build(BuildContext context) {
    final statusStr = project['status'] as String;
    final schedPct = (project['schedulePercent'] as int).clamp(0, 100);
    final budgetPct = project['budgetPercent'] as int;
    final isOverBudget = budgetPct > 100;

    // Gradient based on status
    final List<Color> gradientColors = statusStr == 'delayed'
        ? [const Color(0xFF7B1C1C), const Color(0xFF1A0A0A)]
        : statusStr == 'atRisk'
        ? [const Color(0xFF6B3200), const Color(0xFF1A0A00)]
        : [const Color(0xFF1A56A0), const Color(0xFF0A2E5C)];

    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: gradientColors,
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: Stack(
        children: [
          // Blueprint grid overlay
          Positioned.fill(child: CustomPaint(painter: _BlueprintGridPainter())),
          // Content
          Positioned(
            bottom: 56,
            left: 20,
            right: 20,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Project ID + Status
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 3,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.white.withAlpha(38),
                        borderRadius: BorderRadius.circular(5),
                      ),
                      child: Text(
                        project['id'] as String,
                        style: GoogleFonts.ibmPlexMono(
                          fontSize: 11,
                          color: Colors.white70,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    StatusBadgeWidget.fromProjectStatus(status),
                  ],
                ),
                const SizedBox(height: 8),
                // Project name
                Text(
                  project['name'] as String,
                  style: GoogleFonts.ibmPlexSans(
                    fontSize: 20,
                    fontWeight: FontWeight.w700,
                    color: Colors.white,
                    height: 1.2,
                  ),
                ),
                const SizedBox(height: 4),
                // Client + location
                Row(
                  children: [
                    Icon(
                      Icons.business_outlined,
                      size: 12,
                      color: Colors.white60,
                    ),
                    const SizedBox(width: 4),
                    Text(
                      project['client'] as String,
                      style: GoogleFonts.ibmPlexSans(
                        fontSize: 12,
                        color: Colors.white70,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Icon(
                      Icons.location_on_outlined,
                      size: 12,
                      color: Colors.white60,
                    ),
                    const SizedBox(width: 4),
                    Text(
                      project['location'] as String,
                      style: GoogleFonts.ibmPlexSans(
                        fontSize: 12,
                        color: Colors.white70,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                // Progress bars
                Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'Schedule',
                                style: GoogleFonts.ibmPlexSans(
                                  fontSize: 10,
                                  color: Colors.white60,
                                ),
                              ),
                              Text(
                                '$schedPct%',
                                style: GoogleFonts.ibmPlexMono(
                                  fontSize: 10,
                                  color: Colors.white,
                                  fontWeight: FontWeight.w600,
                                  fontFeatures: const [
                                    FontFeature.tabularFigures(),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 4),
                          ClipRRect(
                            borderRadius: BorderRadius.circular(3),
                            child: LinearProgressIndicator(
                              value: schedPct / 100.0,
                              minHeight: 5,
                              backgroundColor: Colors.white.withAlpha(51),
                              valueColor: const AlwaysStoppedAnimation<Color>(
                                Colors.white,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'Budget Used',
                                style: GoogleFonts.ibmPlexSans(
                                  fontSize: 10,
                                  color: Colors.white60,
                                ),
                              ),
                              Text(
                                '$budgetPct%',
                                style: GoogleFonts.ibmPlexMono(
                                  fontSize: 10,
                                  color: isOverBudget
                                      ? const Color(0xFFFF8A80)
                                      : Colors.white,
                                  fontWeight: FontWeight.w600,
                                  fontFeatures: const [
                                    FontFeature.tabularFigures(),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 4),
                          ClipRRect(
                            borderRadius: BorderRadius.circular(3),
                            child: LinearProgressIndicator(
                              value: (budgetPct / 100.0).clamp(0.0, 1.0),
                              minHeight: 5,
                              backgroundColor: Colors.white.withAlpha(51),
                              valueColor: AlwaysStoppedAnimation<Color>(
                                isOverBudget
                                    ? const Color(0xFFFF8A80)
                                    : Colors.white,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _BlueprintGridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white.withAlpha(15)
      ..strokeWidth = 0.8;
    const step = 20.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
