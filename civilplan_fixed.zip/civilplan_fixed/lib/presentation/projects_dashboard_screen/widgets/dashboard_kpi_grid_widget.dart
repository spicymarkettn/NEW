import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../theme/app_theme.dart';

class DashboardKpiGridWidget extends StatelessWidget {
  const DashboardKpiGridWidget({super.key});

  @override
  Widget build(BuildContext context) {
    // TODO: Replace with actual KPI data from repository in production
    final kpis = [
      _KpiData(
        label: 'Active Projects',
        value: '8',
        icon: Icons.construction_rounded,
        iconColor: AppTheme.primary,
        iconBg: AppTheme.primaryContainer,
        trend: '+2 this month',
        trendPositive: true,
      ),
      _KpiData(
        label: 'Overdue Tasks',
        value: '14',
        icon: Icons.warning_amber_rounded,
        iconColor: AppTheme.errorColor,
        iconBg: AppTheme.errorContainer,
        trend: '↑ 3 since last week',
        trendPositive: false,
      ),
      _KpiData(
        label: 'Budget Alerts',
        value: '3',
        icon: Icons.account_balance_wallet_outlined,
        iconColor: AppTheme.warning,
        iconBg: AppTheme.warningContainer,
        trend: '2 projects at >90%',
        trendPositive: false,
      ),
      _KpiData(
        label: 'On-Track Rate',
        value: '62%',
        icon: Icons.trending_up_rounded,
        iconColor: AppTheme.secondary,
        iconBg: AppTheme.secondaryContainer,
        trend: '5 of 8 projects',
        trendPositive: true,
      ),
    ];

    return GridView.count(
      crossAxisCount: 2,
      crossAxisSpacing: 10,
      mainAxisSpacing: 10,
      childAspectRatio: 1.55,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      children: kpis.map((kpi) => _buildKpiCard(kpi)).toList(),
    );
  }

  Widget _buildKpiCard(_KpiData kpi) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFE5E7EB), width: 1),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha(10),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                width: 32,
                height: 32,
                decoration: BoxDecoration(
                  color: kpi.iconBg,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(kpi.icon, size: 16, color: kpi.iconColor),
              ),
              Text(
                kpi.value,
                style: GoogleFonts.ibmPlexMono(
                  fontSize: 22,
                  fontWeight: FontWeight.w700,
                  color: AppTheme.onSurface,
                  fontFeatures: const [FontFeature.tabularFigures()],
                ),
              ),
            ],
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                kpi.label,
                style: GoogleFonts.ibmPlexSans(
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                  color: AppTheme.onSurface,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                kpi.trend,
                style: GoogleFonts.ibmPlexSans(
                  fontSize: 10,
                  color: kpi.trendPositive
                      ? AppTheme.secondary
                      : AppTheme.warning,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _KpiData {
  final String label;
  final String value;
  final IconData icon;
  final Color iconColor;
  final Color iconBg;
  final String trend;
  final bool trendPositive;

  const _KpiData({
    required this.label,
    required this.value,
    required this.icon,
    required this.iconColor,
    required this.iconBg,
    required this.trend,
    required this.trendPositive,
  });
}
