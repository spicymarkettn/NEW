import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../theme/app_theme.dart';

class OfflineBannerWidget extends StatelessWidget {
  const OfflineBannerWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      color: AppTheme.warning.withAlpha(31),
      child: Row(
        children: [
          Icon(Icons.cloud_off_rounded, size: 14, color: AppTheme.warning),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              'You\'re offline — viewing cached data. Changes will sync when connected.',
              style: GoogleFonts.ibmPlexSans(
                fontSize: 11,
                color: AppTheme.warning,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
