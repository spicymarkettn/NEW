import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../theme/app_theme.dart';
import '../../../widgets/status_badge_widget.dart';

class ProjectListWidget extends StatefulWidget {
  final AnimationController animationController;
  final Function(Map<String, dynamic>) onProjectTap;

  const ProjectListWidget({
    super.key,
    required this.animationController,
    required this.onProjectTap,
  });

  @override
  State<ProjectListWidget> createState() => ProjectListWidgetState();
}

class ProjectListWidgetState extends State<ProjectListWidget> {
  // TODO: Replace with actual data from repository in production
  final List<Map<String, dynamic>> _projectMaps = [
    {
      'id': 'PRJ-001',
      'name': 'Ikeja Flyover Bridge',
      'client': 'Lagos State PWD',
      'status': 'onTrack',
      'schedulePercent': 67,
      'budgetPercent': 74,
      'budgetTotal': 4200000,
      'budgetSpent': 3108000,
      'daysRemaining': 84,
      'lastUpdated': '2h ago',
      'location': 'Lagos, Nigeria',
      'teamSize': 24,
      'openTasks': 12,
    },
    {
      'id': 'PRJ-002',
      'name': 'Lekki-Epe Highway Expansion',
      'client': 'FERMA',
      'status': 'delayed',
      'schedulePercent': 42,
      'budgetPercent': 105,
      'budgetTotal': 12800000,
      'budgetSpent': 13440000,
      'daysRemaining': -18,
      'lastUpdated': '5h ago',
      'location': 'Lagos, Nigeria',
      'teamSize': 68,
      'openTasks': 31,
    },
    {
      'id': 'PRJ-003',
      'name': 'Abuja Storm Drainage',
      'client': 'FCT-AEPB',
      'status': 'onTrack',
      'schedulePercent': 89,
      'budgetPercent': 91,
      'budgetTotal': 2900000,
      'budgetSpent': 2639000,
      'daysRemaining': 11,
      'lastUpdated': '1d ago',
      'location': 'Abuja, Nigeria',
      'teamSize': 18,
      'openTasks': 4,
    },
    {
      'id': 'PRJ-004',
      'name': 'Port Harcourt Terminal Upgrade',
      'client': 'NIMASA',
      'status': 'atRisk',
      'schedulePercent': 55,
      'budgetPercent': 108,
      'budgetTotal': 7500000,
      'budgetSpent': 8100000,
      'daysRemaining': 47,
      'lastUpdated': '3h ago',
      'location': 'Port Harcourt, Nigeria',
      'teamSize': 42,
      'openTasks': 19,
    },
    {
      'id': 'PRJ-005',
      'name': 'Kano Ring Road Phase II',
      'client': 'Kano State MOW',
      'status': 'onTrack',
      'schedulePercent': 31,
      'budgetPercent': 29,
      'budgetTotal': 5100000,
      'budgetSpent': 1479000,
      'daysRemaining': 210,
      'lastUpdated': '6h ago',
      'location': 'Kano, Nigeria',
      'teamSize': 55,
      'openTasks': 44,
    },
    {
      'id': 'PRJ-006',
      'name': 'Enugu River Bridge Rehab',
      'client': 'Enugu State MWRH',
      'status': 'planning',
      'schedulePercent': 8,
      'budgetPercent': 5,
      'budgetTotal': 3300000,
      'budgetSpent': 165000,
      'daysRemaining': 365,
      'lastUpdated': '2d ago',
      'location': 'Enugu, Nigeria',
      'teamSize': 9,
      'openTasks': 7,
    },
    {
      'id': 'PRJ-007',
      'name': 'Ibadan Water Treatment Plant',
      'client': 'OYWSC',
      'status': 'onHold',
      'schedulePercent': 23,
      'budgetPercent': 19,
      'budgetTotal': 6800000,
      'budgetSpent': 1292000,
      'daysRemaining': 0,
      'lastUpdated': '1w ago',
      'location': 'Ibadan, Nigeria',
      'teamSize': 0,
      'openTasks': 0,
    },
    {
      'id': 'PRJ-008',
      'name': 'Calabar Coastal Protection',
      'client': 'CRSG-MOW',
      'status': 'atRisk',
      'schedulePercent': 61,
      'budgetPercent': 78,
      'budgetTotal': 4600000,
      'budgetSpent': 3588000,
      'daysRemaining': 29,
      'lastUpdated': '4h ago',
      'location': 'Calabar, Nigeria',
      'teamSize': 33,
      'openTasks': 16,
    },
  ];

  /// Called by dashboard to add a newly created project
  void addProject(Map<String, dynamic> project) {
    setState(() {
      _projectMaps.insert(0, project);
    });
  }

  /// Called by dashboard to trigger a visual refresh
  void refreshProjects() {
    setState(() {});
  }

  /// Called by project detail screen to update an edited project
  void updateProject(Map<String, dynamic> updated) {
    final idx = _projectMaps.indexWhere((p) => p['id'] == updated['id']);
    if (idx != -1) {
      setState(() {
        _projectMaps[idx] = updated;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: List.generate(_projectMaps.length, (index) {
        final delay = (index * 60).clamp(0, 400);
        return _AnimatedProjectCard(
          project: _projectMaps[index],
          animationController: widget.animationController,
          delay: delay,
          onTap: () => widget.onProjectTap(_projectMaps[index]),
          onEdit: (updated) => updateProject(updated),
        );
      }),
    );
  }
}

class _AnimatedProjectCard extends StatelessWidget {
  final Map<String, dynamic> project;
  final AnimationController animationController;
  final int delay;
  final VoidCallback onTap;
  final Function(Map<String, dynamic>) onEdit;

  const _AnimatedProjectCard({
    required this.project,
    required this.animationController,
    required this.delay,
    required this.onTap,
    required this.onEdit,
  });

  @override
  Widget build(BuildContext context) {
    final animation = CurvedAnimation(
      parent: animationController,
      curve: Interval(
        delay / 1000.0,
        (delay + 400) / 1000.0,
        curve: Curves.easeOutCubic,
      ),
    );

    return AnimatedBuilder(
      animation: animation,
      builder: (context, child) {
        return FadeTransition(
          opacity: animation,
          child: SlideTransition(
            position: Tween<Offset>(
              begin: const Offset(0, 0.08),
              end: Offset.zero,
            ).animate(animation),
            child: child,
          ),
        );
      },
      child: Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: _ProjectCard(project: project, onTap: onTap, onEdit: onEdit),
      ),
    );
  }
}

class _ProjectCard extends StatelessWidget {
  final Map<String, dynamic> project;
  final VoidCallback onTap;
  final Function(Map<String, dynamic>) onEdit;

  const _ProjectCard({
    required this.project,
    required this.onTap,
    required this.onEdit,
  });

  ProjectStatus _parseStatus(String s) {
    switch (s) {
      case 'onTrack':
        return ProjectStatus.onTrack;
      case 'atRisk':
        return ProjectStatus.atRisk;
      case 'delayed':
        return ProjectStatus.delayed;
      case 'completed':
        return ProjectStatus.completed;
      case 'planning':
        return ProjectStatus.planning;
      case 'onHold':
        return ProjectStatus.onHold;
      default:
        return ProjectStatus.onTrack;
    }
  }

  Color _scheduleBarColor(int pct, String status) {
    if (status == 'delayed') return AppTheme.errorColor;
    if (status == 'atRisk') return AppTheme.warning;
    return AppTheme.secondary;
  }

  @override
  Widget build(BuildContext context) {
    final status = _parseStatus(project['status'] as String);
    final schedPct = (project['schedulePercent'] as int).clamp(0, 100);
    final budgetPct = project['budgetPercent'] as int;
    final daysRemaining = project['daysRemaining'] as int;
    final isOverBudget = budgetPct > 100;
    final isDelayed = daysRemaining < 0;
    final statusStr = project['status'] as String;

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        splashColor: AppTheme.primary.withAlpha(15),
        highlightColor: AppTheme.primary.withAlpha(10),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: AppTheme.surface,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: statusStr == 'delayed'
                  ? AppTheme.errorColor.withAlpha(77)
                  : statusStr == 'atRisk'
                  ? AppTheme.warning.withAlpha(77)
                  : const Color(0xFFE5E7EB),
              width: 1,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withAlpha(10),
                blurRadius: 8,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Row 1: Name + Status badge + Edit button
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Status accent bar
                  Container(
                    width: 3,
                    height: 40,
                    margin: const EdgeInsets.only(right: 10),
                    decoration: BoxDecoration(
                      color: statusStr == 'delayed'
                          ? AppTheme.errorColor
                          : statusStr == 'atRisk'
                          ? AppTheme.warning
                          : statusStr == 'onTrack'
                          ? AppTheme.secondary
                          : statusStr == 'planning'
                          ? AppTheme.primary
                          : AppTheme.muted,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          project['name'] as String,
                          style: GoogleFonts.ibmPlexSans(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            color: AppTheme.onSurface,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        const SizedBox(height: 2),
                        Text(
                          '${project['client']} · ${project['location']}',
                          style: GoogleFonts.ibmPlexSans(
                            fontSize: 11,
                            color: AppTheme.muted,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 6),
                  StatusBadgeWidget.fromProjectStatus(status),
                  // Edit icon button
                  GestureDetector(
                    onTap: () => _showEditSheet(context),
                    child: Container(
                      margin: const EdgeInsets.only(left: 6),
                      padding: const EdgeInsets.all(4),
                      decoration: BoxDecoration(
                        color: AppTheme.surfaceVariant,
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: const Icon(
                        Icons.edit_outlined,
                        size: 14,
                        color: AppTheme.muted,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              // Row 2: Schedule progress
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Schedule',
                        style: GoogleFonts.ibmPlexSans(
                          fontSize: 11,
                          color: AppTheme.muted,
                        ),
                      ),
                      Text(
                        '$schedPct%',
                        style: GoogleFonts.ibmPlexMono(
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                          color: _scheduleBarColor(schedPct, statusStr),
                          fontFeatures: const [FontFeature.tabularFigures()],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(3),
                    child: LinearProgressIndicator(
                      value: schedPct / 100.0,
                      minHeight: 5,
                      backgroundColor: const Color(0xFFE5E7EB),
                      valueColor: AlwaysStoppedAnimation<Color>(
                        _scheduleBarColor(schedPct, statusStr),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              // Row 3: Metadata chips
              Row(
                children: [
                  _buildMetaChip(
                    Icons.account_balance_wallet_outlined,
                    'Budget: $budgetPct%',
                    isOverBudget ? AppTheme.errorColor : AppTheme.muted,
                    isOverBudget
                        ? AppTheme.errorContainer
                        : const Color(0xFFF3F4F6),
                  ),
                  const SizedBox(width: 6),
                  _buildMetaChip(
                    isDelayed
                        ? Icons.schedule_rounded
                        : Icons.calendar_today_outlined,
                    isDelayed
                        ? '${daysRemaining.abs()}d overdue'
                        : '$daysRemaining days left',
                    isDelayed ? AppTheme.errorColor : AppTheme.muted,
                    isDelayed
                        ? AppTheme.errorContainer
                        : const Color(0xFFF3F4F6),
                  ),
                  const SizedBox(width: 6),
                  _buildMetaChip(
                    Icons.task_alt_rounded,
                    '${project['openTasks']} tasks',
                    AppTheme.muted,
                    const Color(0xFFF3F4F6),
                  ),
                  const Spacer(),
                  Text(
                    project['lastUpdated'] as String,
                    style: GoogleFonts.ibmPlexSans(
                      fontSize: 10,
                      color: AppTheme.muted,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showEditSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _EditProjectSheet(project: project, onSaved: onEdit),
    );
  }

  Widget _buildMetaChip(
    IconData icon,
    String label,
    Color color,
    Color bgColor,
  ) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(5),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 10, color: color),
          const SizedBox(width: 3),
          Text(
            label,
            style: GoogleFonts.ibmPlexSans(
              fontSize: 10,
              color: color,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Edit Project Bottom Sheet ─────────────────────────────────────────────────

class _EditProjectSheet extends StatefulWidget {
  final Map<String, dynamic> project;
  final Function(Map<String, dynamic>) onSaved;

  const _EditProjectSheet({required this.project, required this.onSaved});

  @override
  State<_EditProjectSheet> createState() => _EditProjectSheetState();
}

class _EditProjectSheetState extends State<_EditProjectSheet> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _nameCtrl;
  late TextEditingController _clientCtrl;
  late TextEditingController _locationCtrl;
  late TextEditingController _engineerCtrl;
  late TextEditingController _descCtrl;
  late TextEditingController _budgetCtrl;
  late TextEditingController _scheduleCtrl;
  late String _selectedStatus;
  bool _isSaving = false;

  final List<Map<String, String>> _statusOptions = [
    {'value': 'planning', 'label': 'Planning'},
    {'value': 'onTrack', 'label': 'On Track'},
    {'value': 'atRisk', 'label': 'At Risk'},
    {'value': 'delayed', 'label': 'Delayed'},
    {'value': 'onHold', 'label': 'On Hold'},
    {'value': 'completed', 'label': 'Completed'},
  ];

  @override
  void initState() {
    super.initState();
    final p = widget.project;
    _nameCtrl = TextEditingController(text: p['name'] as String? ?? '');
    _clientCtrl = TextEditingController(text: p['client'] as String? ?? '');
    _locationCtrl = TextEditingController(text: p['location'] as String? ?? '');
    _engineerCtrl = TextEditingController(text: p['engineer'] as String? ?? '');
    _descCtrl = TextEditingController(text: p['description'] as String? ?? '');
    _budgetCtrl = TextEditingController(
      text: (p['budgetTotal'] as num?)?.toStringAsFixed(0) ?? '0',
    );
    _scheduleCtrl = TextEditingController(
      text: (p['schedulePercent'] as int?)?.toString() ?? '0',
    );
    _selectedStatus = p['status'] as String? ?? 'planning';
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _clientCtrl.dispose();
    _locationCtrl.dispose();
    _engineerCtrl.dispose();
    _descCtrl.dispose();
    _budgetCtrl.dispose();
    _scheduleCtrl.dispose();
    super.dispose();
  }

  void _save() {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _isSaving = true);

    final budget = double.tryParse(_budgetCtrl.text.replaceAll(',', '')) ?? 0.0;
    final schedule = int.tryParse(_scheduleCtrl.text) ?? 0;
    final budgetSpent = widget.project['budgetSpent'] as num? ?? 0;
    final budgetPct = budget > 0 ? ((budgetSpent / budget) * 100).round() : 0;

    final updated = Map<String, dynamic>.from(widget.project)
      ..['name'] = _nameCtrl.text.trim()
      ..['client'] = _clientCtrl.text.trim()
      ..['location'] = _locationCtrl.text.trim()
      ..['engineer'] = _engineerCtrl.text.trim()
      ..['description'] = _descCtrl.text.trim()
      ..['budgetTotal'] = budget
      ..['contractValue'] = budget
      ..['schedulePercent'] = schedule.clamp(0, 100)
      ..['budgetPercent'] = budgetPct
      ..['status'] = _selectedStatus
      ..['lastUpdated'] = 'Just now';

    Future.delayed(const Duration(milliseconds: 400), () {
      if (mounted) {
        Navigator.pop(context);
        widget.onSaved(updated);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final bottomPad = MediaQuery.of(context).viewInsets.bottom;
    return Container(
      decoration: const BoxDecoration(
        color: AppTheme.surface,
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      padding: EdgeInsets.fromLTRB(20, 0, 20, bottomPad + 20),
      child: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 36,
                  height: 4,
                  margin: const EdgeInsets.only(top: 12, bottom: 16),
                  decoration: BoxDecoration(
                    color: const Color(0xFFD1D5DB),
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              Row(
                children: [
                  Expanded(
                    child: Text(
                      'Edit Project',
                      style: GoogleFonts.ibmPlexSans(
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        color: AppTheme.onSurface,
                      ),
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: AppTheme.primaryContainer,
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(
                      widget.project['id'] as String? ?? '',
                      style: GoogleFonts.ibmPlexMono(
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                        color: AppTheme.primary,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 4),
              Text(
                'Update project information',
                style: GoogleFonts.ibmPlexSans(
                  fontSize: 13,
                  color: AppTheme.muted,
                ),
              ),
              const SizedBox(height: 20),
              _buildField(
                'Project Name *',
                _nameCtrl,
                'Project name',
                validator: (v) =>
                    (v == null || v.trim().isEmpty) ? 'Required' : null,
              ),
              const SizedBox(height: 14),
              _buildField(
                'Client / Owner *',
                _clientCtrl,
                'Client name',
                validator: (v) =>
                    (v == null || v.trim().isEmpty) ? 'Required' : null,
              ),
              const SizedBox(height: 14),
              Row(
                children: [
                  Expanded(
                    child: _buildField(
                      'Location',
                      _locationCtrl,
                      'City, Country',
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _buildField('Lead Engineer', _engineerCtrl, 'Name'),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              Row(
                children: [
                  Expanded(
                    child: _buildField(
                      'Contract Budget (USD)',
                      _budgetCtrl,
                      '0',
                      keyboardType: TextInputType.number,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _buildField(
                      'Schedule %',
                      _scheduleCtrl,
                      '0–100',
                      keyboardType: TextInputType.number,
                      validator: (v) {
                        final n = int.tryParse(v ?? '');
                        if (n == null || n < 0 || n > 100) return '0–100';
                        return null;
                      },
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Status',
                    style: GoogleFonts.ibmPlexSans(
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      color: AppTheme.onSurface,
                    ),
                  ),
                  const SizedBox(height: 6),
                  DropdownButtonFormField<String>(
                    initialValue: _selectedStatus,
                    decoration: InputDecoration(
                      filled: true,
                      fillColor: AppTheme.surfaceVariant,
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 14,
                        vertical: 12,
                      ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: const BorderSide(color: Color(0xFFE5E7EB)),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: const BorderSide(color: Color(0xFFE5E7EB)),
                      ),
                    ),
                    items: _statusOptions
                        .map(
                          (s) => DropdownMenuItem(
                            value: s['value'],
                            child: Text(
                              s['label']!,
                              style: GoogleFonts.ibmPlexSans(fontSize: 14),
                            ),
                          ),
                        )
                        .toList(),
                    onChanged: (v) =>
                        setState(() => _selectedStatus = v ?? 'planning'),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              _buildField(
                'Description',
                _descCtrl,
                'Project scope and objectives',
                maxLines: 3,
              ),
              const SizedBox(height: 24),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.pop(context),
                      child: const Text('Cancel'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    flex: 2,
                    child: ElevatedButton(
                      onPressed: _isSaving ? null : _save,
                      child: _isSaving
                          ? const SizedBox(
                              height: 18,
                              width: 18,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Colors.white,
                              ),
                            )
                          : const Text('Save Changes'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildField(
    String label,
    TextEditingController controller,
    String hint, {
    String? Function(String?)? validator,
    TextInputType keyboardType = TextInputType.text,
    int maxLines = 1,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: GoogleFonts.ibmPlexSans(
            fontSize: 13,
            fontWeight: FontWeight.w600,
            color: AppTheme.onSurface,
          ),
        ),
        const SizedBox(height: 6),
        TextFormField(
          controller: controller,
          keyboardType: keyboardType,
          maxLines: maxLines,
          validator: validator,
          style: GoogleFonts.ibmPlexSans(
            fontSize: 14,
            color: AppTheme.onSurface,
          ),
          decoration: InputDecoration(
            hintText: hint,
            filled: true,
            fillColor: AppTheme.surfaceVariant,
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 14,
              vertical: 12,
            ),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: const BorderSide(color: Color(0xFFE5E7EB)),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: const BorderSide(color: Color(0xFFE5E7EB)),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: const BorderSide(color: AppTheme.primary, width: 2),
            ),
            errorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: const BorderSide(color: AppTheme.errorColor),
            ),
          ),
        ),
      ],
    );
  }
}
