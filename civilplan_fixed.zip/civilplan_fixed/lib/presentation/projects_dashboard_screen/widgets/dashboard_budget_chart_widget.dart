import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:fl_chart/fl_chart.dart';
import '../../../theme/app_theme.dart';

class DashboardBudgetChartWidget extends StatefulWidget {
  const DashboardBudgetChartWidget({super.key});

  @override
  State<DashboardBudgetChartWidget> createState() =>
      _DashboardBudgetChartWidgetState();
}

class _DashboardBudgetChartWidgetState
    extends State<DashboardBudgetChartWidget> {
  int _touchedIndex = -1;

  // TODO: Replace with actual budget data from repository in production
  // Budget vs Actual spend per project (in $M)
  final List<_BudgetEntry> _entries = [
    _BudgetEntry(label: 'Ikeja\nBridge', budget: 4.2, actual: 3.1),
    _BudgetEntry(label: 'Lekki\nHwy', budget: 12.8, actual: 13.4),
    _BudgetEntry(label: 'Abuja\nDrain', budget: 2.9, actual: 2.6),
    _BudgetEntry(label: 'PH\nTerminal', budget: 7.5, actual: 8.1),
    _BudgetEntry(label: 'Kano\nRoad', budget: 5.1, actual: 4.3),
    _BudgetEntry(label: 'Enugu\nBridge', budget: 3.3, actual: 1.8),
  ];

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFE5E7EB), width: 1),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha(10),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Budget vs Actual Spend',
                    style: GoogleFonts.ibmPlexSans(
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      color: AppTheme.onSurface,
                    ),
                  ),
                  Text(
                    'Per project — in \$M USD',
                    style: GoogleFonts.ibmPlexSans(
                      fontSize: 11,
                      color: AppTheme.muted,
                    ),
                  ),
                ],
              ),
              Row(
                children: [
                  _buildLegendDot(AppTheme.primary, 'Budget'),
                  const SizedBox(width: 12),
                  _buildLegendDot(AppTheme.secondary, 'Actual'),
                ],
              ),
            ],
          ),
          const SizedBox(height: 16),
          SizedBox(
            height: 180,
            child: BarChart(
              BarChartData(
                alignment: BarChartAlignment.spaceAround,
                maxY: 16,
                barTouchData: BarTouchData(
                  touchCallback: (event, response) {
                    setState(() {
                      if (response?.spot != null &&
                          event is! FlPointerExitEvent) {
                        _touchedIndex = response!.spot!.touchedBarGroupIndex;
                      } else {
                        _touchedIndex = -1;
                      }
                    });
                  },
                  touchTooltipData: BarTouchTooltipData(
                    tooltipRoundedRadius: 8,
                    getTooltipItem: (group, groupIndex, rod, rodIndex) {
                      final entry = _entries[groupIndex];
                      final label = rodIndex == 0 ? 'Budget' : 'Actual';
                      final value = rodIndex == 0 ? entry.budget : entry.actual;
                      final isOverBudget =
                          rodIndex == 1 && entry.actual > entry.budget;
                      return BarTooltipItem(
                        '$label\n\$${value.toStringAsFixed(1)}M',
                        GoogleFonts.ibmPlexMono(
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                          color: isOverBudget
                              ? AppTheme.errorColor
                              : Colors.white,
                        ),
                      );
                    },
                  ),
                ),
                titlesData: FlTitlesData(
                  show: true,
                  bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 36,
                      getTitlesWidget: (value, meta) {
                        final idx = value.toInt();
                        if (idx < 0 || idx >= _entries.length) {
                          return const SizedBox.shrink();
                        }
                        return Padding(
                          padding: const EdgeInsets.only(top: 4),
                          child: Text(
                            _entries[idx].label,
                            style: GoogleFonts.ibmPlexSans(
                              fontSize: 9,
                              color: AppTheme.muted,
                            ),
                            textAlign: TextAlign.center,
                          ),
                        );
                      },
                    ),
                  ),
                  leftTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 32,
                      interval: 4,
                      getTitlesWidget: (value, meta) => Text(
                        '\$${value.toInt()}M',
                        style: GoogleFonts.ibmPlexMono(
                          fontSize: 9,
                          color: AppTheme.muted,
                        ),
                      ),
                    ),
                  ),
                  topTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false),
                  ),
                  rightTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false),
                  ),
                ),
                gridData: FlGridData(
                  drawVerticalLine: false,
                  horizontalInterval: 4,
                  getDrawingHorizontalLine: (_) => FlLine(
                    color: const Color(0xFFE5E7EB),
                    strokeWidth: 1,
                    dashArray: [4, 4],
                  ),
                ),
                borderData: FlBorderData(show: false),
                barGroups: List.generate(_entries.length, (i) {
                  final e = _entries[i];
                  final isTouched = i == _touchedIndex;
                  final isOverBudget = e.actual > e.budget;
                  return BarChartGroupData(
                    x: i,
                    barRods: [
                      BarChartRodData(
                        toY: e.budget,
                        color: isTouched
                            ? AppTheme.primary
                            : AppTheme.primary.withAlpha(179),
                        width: 8,
                        borderRadius: const BorderRadius.vertical(
                          top: Radius.circular(4),
                        ),
                      ),
                      BarChartRodData(
                        toY: e.actual,
                        color: isOverBudget
                            ? (isTouched
                                  ? AppTheme.errorColor
                                  : AppTheme.errorColor.withAlpha(191))
                            : (isTouched
                                  ? AppTheme.secondary
                                  : AppTheme.secondary.withAlpha(191)),
                        width: 8,
                        borderRadius: const BorderRadius.vertical(
                          top: Radius.circular(4),
                        ),
                      ),
                    ],
                    barsSpace: 3,
                  );
                }),
              ),
            ),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                  color: AppTheme.errorColor.withAlpha(204),
                  shape: BoxShape.circle,
                ),
              ),
              const SizedBox(width: 6),
              Text(
                '2 projects over budget — Lekki Hwy & PH Terminal',
                style: GoogleFonts.ibmPlexSans(
                  fontSize: 11,
                  color: AppTheme.errorColor,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildLegendDot(Color color, String label) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 10,
          height: 10,
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        const SizedBox(width: 4),
        Text(
          label,
          style: GoogleFonts.ibmPlexSans(fontSize: 11, color: AppTheme.muted),
        ),
      ],
    );
  }
}

class _BudgetEntry {
  final String label;
  final double budget;
  final double actual;
  const _BudgetEntry({
    required this.label,
    required this.budget,
    required this.actual,
  });
}
