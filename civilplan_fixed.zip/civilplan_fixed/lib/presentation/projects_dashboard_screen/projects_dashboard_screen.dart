import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../routes/app_routes.dart';
import '../../theme/app_theme.dart';
import '../../widgets/loading_skeleton_widget.dart';
import './widgets/dashboard_app_bar_widget.dart';
import './widgets/dashboard_budget_chart_widget.dart';
import './widgets/dashboard_kpi_grid_widget.dart';
import './widgets/offline_banner_widget.dart';
import './widgets/project_list_widget.dart';

class ProjectsDashboardScreen extends StatefulWidget {
  const ProjectsDashboardScreen({super.key});

  @override
  State<ProjectsDashboardScreen> createState() =>
      _ProjectsDashboardScreenState();
}

class _ProjectsDashboardScreenState extends State<ProjectsDashboardScreen>
    with TickerProviderStateMixin {
  bool _isLoading = true;
  final bool _isOffline = false;
  int _selectedNavIndex = 0;

  late AnimationController _listEntranceController;

  // Key to trigger project list refresh
  final GlobalKey<ProjectListWidgetState> _projectListKey =
      GlobalKey<ProjectListWidgetState>();

  @override
  void initState() {
    super.initState();
    SystemChrome.setSystemUIOverlayStyle(
      SystemUiOverlayStyle.dark.copyWith(statusBarColor: Colors.transparent),
    );
    _listEntranceController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    Future.delayed(const Duration(milliseconds: 900), () {
      if (mounted) {
        setState(() => _isLoading = false);
        _listEntranceController.forward();
      }
    });
  }

  @override
  void dispose() {
    _listEntranceController.dispose();
    super.dispose();
  }

  Future<void> _onRefresh() async {
    setState(() => _isLoading = true);
    _listEntranceController.reset();
    // FIX: refresh the actual project list state, then re-animate
    await Future.delayed(const Duration(milliseconds: 600));
    if (mounted) {
      _projectListKey.currentState?.refreshProjects();
      setState(() => _isLoading = false);
      _listEntranceController.forward();
    }
  }

  void _navigateToProjectDetail(Map<String, dynamic> project) {
    Navigator.pushNamed(
      context,
      AppRoutes.projectDetailScreen,
      arguments: project,
    ).then((_) {
      _projectListKey.currentState?.refreshProjects();
    });
  }

  void _showNewProjectDialog() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _NewProjectSheet(
        onProjectCreated: (newProject) {
          _projectListKey.currentState?.addProject(newProject);
          _listEntranceController.reset();
          _listEntranceController.forward();
        },
      ),
    );
  }

  void _onNavTap(int index) {
    if (index == _selectedNavIndex) return;
    setState(() => _selectedNavIndex = index);
    // FIX: actually navigate for Profile tab (index 2)
    if (index == 2) {
      Navigator.pushNamed(context, AppRoutes.profileScreen).then((_) {
        // Return to dashboard tab after coming back
        if (mounted) setState(() => _selectedNavIndex = 0);
      });
    }
    // Index 1 (Projects) stays on this screen — could filter later
  }

  @override
  Widget build(BuildContext context) {
    final isTablet = MediaQuery.of(context).size.width >= 600;

    return Scaffold(
      backgroundColor: AppTheme.background,
      body: SafeArea(
        child: Column(
          children: [
            const DashboardAppBarWidget(),
            if (_isOffline) const OfflineBannerWidget(),
            Expanded(
              child: _isLoading
                  ? const SkeletonDashboard()
                  : RefreshIndicator(
                      onRefresh: _onRefresh,
                      color: AppTheme.primary,
                      child: isTablet
                          ? _buildTabletLayout()
                          : _buildPhoneLayout(),
                    ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: _buildBottomNav(),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _showNewProjectDialog,
        icon: const Icon(Icons.add_rounded),
        label: const Text('New Project'),
        backgroundColor: AppTheme.primary,
        foregroundColor: Colors.white,
        elevation: 2,
      ),
    );
  }

  Widget _buildPhoneLayout() {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
      children: [
        const DashboardKpiGridWidget(),
        const SizedBox(height: 20),
        const DashboardBudgetChartWidget(),
        const SizedBox(height: 20),
        _buildSectionHeader('Active Projects', '8 projects'),
        const SizedBox(height: 12),
        ProjectListWidget(
          key: _projectListKey,
          animationController: _listEntranceController,
          onProjectTap: _navigateToProjectDetail,
        ),
      ],
    );
  }

  Widget _buildTabletLayout() {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          flex: 6,
          child: ListView(
            padding: const EdgeInsets.fromLTRB(20, 16, 12, 100),
            children: [
              _buildSectionHeader('Active Projects', '8 projects'),
              const SizedBox(height: 12),
              ProjectListWidget(
                key: _projectListKey,
                animationController: _listEntranceController,
                onProjectTap: _navigateToProjectDetail,
              ),
            ],
          ),
        ),
        Expanded(
          flex: 4,
          child: ListView(
            padding: const EdgeInsets.fromLTRB(12, 16, 20, 100),
            children: [
              const DashboardKpiGridWidget(),
              const SizedBox(height: 16),
              const DashboardBudgetChartWidget(),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildSectionHeader(String title, String subtitle) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: const TextStyle(
                fontSize: 17,
                fontWeight: FontWeight.w700,
                color: AppTheme.onSurface,
              ),
            ),
            Text(
              subtitle,
              style: const TextStyle(fontSize: 12, color: AppTheme.muted),
            ),
          ],
        ),
        TextButton(onPressed: () {}, child: const Text('View All')),
      ],
    );
  }

  Widget _buildBottomNav() {
    return NavigationBar(
      selectedIndex: _selectedNavIndex,
      onDestinationSelected: _onNavTap,
      destinations: const [
        NavigationDestination(
          icon: Icon(Icons.dashboard_outlined),
          selectedIcon: Icon(Icons.dashboard_rounded),
          label: 'Dashboard',
        ),
        NavigationDestination(
          icon: Icon(Icons.folder_outlined),
          selectedIcon: Icon(Icons.folder_rounded),
          label: 'Projects',
        ),
        NavigationDestination(
          icon: Icon(Icons.person_outline_rounded),
          selectedIcon: Icon(Icons.person_rounded),
          label: 'Profile',
        ),
      ],
    );
  }
}

// ─── New Project Bottom Sheet ──────────────────────────────────────────────────

class _NewProjectSheet extends StatefulWidget {
  final Function(Map<String, dynamic>) onProjectCreated;

  const _NewProjectSheet({required this.onProjectCreated});

  @override
  State<_NewProjectSheet> createState() => _NewProjectSheetState();
}

class _NewProjectSheetState extends State<_NewProjectSheet> {
  final _formKey = GlobalKey<FormState>();
  final _nameCtrl = TextEditingController();
  final _clientCtrl = TextEditingController();
  final _locationCtrl = TextEditingController();
  final _engineerCtrl = TextEditingController();
  final _descCtrl = TextEditingController();
  final _budgetCtrl = TextEditingController();
  String _selectedStatus = 'planning';
  bool _isSaving = false;

  final List<Map<String, String>> _statusOptions = [
    {'value': 'planning', 'label': 'Planning'},
    {'value': 'onTrack', 'label': 'On Track'},
    {'value': 'atRisk', 'label': 'At Risk'},
    {'value': 'delayed', 'label': 'Delayed'},
    {'value': 'onHold', 'label': 'On Hold'},
  ];

  @override
  void dispose() {
    _nameCtrl.dispose();
    _clientCtrl.dispose();
    _locationCtrl.dispose();
    _engineerCtrl.dispose();
    _descCtrl.dispose();
    _budgetCtrl.dispose();
    super.dispose();
  }

  void _save() {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _isSaving = true);

    final budget = double.tryParse(_budgetCtrl.text.replaceAll(',', '')) ?? 0.0;
    final newProject = {
      'id':
          'PRJ-${DateTime.now().millisecondsSinceEpoch.toString().substring(7)}',
      'name': _nameCtrl.text.trim(),
      'client': _clientCtrl.text.trim(),
      'status': _selectedStatus,
      'schedulePercent': 0,
      'budgetPercent': 0,
      'budgetTotal': budget,
      'budgetSpent': 0.0,
      'daysRemaining': 365,
      'lastUpdated': 'Just now',
      'location': _locationCtrl.text.trim(),
      'teamSize': 0,
      'openTasks': 0,
      'engineer': _engineerCtrl.text.trim(),
      'description': _descCtrl.text.trim(),
      'startDate': _formatDate(DateTime.now()),
      'endDate': _formatDate(DateTime.now().add(const Duration(days: 365))),
      'contractValue': budget,
    };

    Future.delayed(const Duration(milliseconds: 400), () {
      if (mounted) {
        Navigator.pop(context);
        widget.onProjectCreated(newProject);
      }
    });
  }

  String _formatDate(DateTime dt) {
    const months = [
      'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
      'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
    ];
    return '${months[dt.month - 1]} ${dt.day}, ${dt.year}';
  }

  @override
  Widget build(BuildContext context) {
    final bottomPad = MediaQuery.of(context).viewInsets.bottom;
    return Container(
      decoration: const BoxDecoration(
        color: AppTheme.surface,
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      padding: EdgeInsets.fromLTRB(20, 0, 20, bottomPad + 20),
      child: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 36,
                  height: 4,
                  margin: const EdgeInsets.only(top: 12, bottom: 16),
                  decoration: BoxDecoration(
                    color: const Color(0xFFD1D5DB),
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              Text(
                'New Project',
                style: GoogleFonts.ibmPlexSans(
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                  color: AppTheme.onSurface,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                'Fill in the project details to get started',
                style: GoogleFonts.ibmPlexSans(
                  fontSize: 13,
                  color: AppTheme.muted,
                ),
              ),
              const SizedBox(height: 20),
              _buildField(
                'Project Name *',
                _nameCtrl,
                'e.g. Abuja Ring Road Phase III',
                validator: (v) => (v == null || v.trim().isEmpty)
                    ? 'Project name is required'
                    : null,
              ),
              const SizedBox(height: 14),
              _buildField(
                'Client / Owner *',
                _clientCtrl,
                'e.g. FCT Ministry of Works',
                validator: (v) => (v == null || v.trim().isEmpty)
                    ? 'Client is required'
                    : null,
              ),
              const SizedBox(height: 14),
              _buildField('Location', _locationCtrl, 'e.g. Abuja, Nigeria'),
              const SizedBox(height: 14),
              _buildField('Lead Engineer', _engineerCtrl, 'e.g. Amara Nwosu'),
              const SizedBox(height: 14),
              _buildField(
                'Contract Budget (USD)',
                _budgetCtrl,
                'e.g. 5000000',
                keyboardType: TextInputType.number,
              ),
              const SizedBox(height: 14),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Initial Status',
                    style: GoogleFonts.ibmPlexSans(
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      color: AppTheme.onSurface,
                    ),
                  ),
                  const SizedBox(height: 6),
                  DropdownButtonFormField<String>(
                    initialValue: _selectedStatus,
                    decoration: InputDecoration(
                      filled: true,
                      fillColor: AppTheme.surfaceVariant,
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 14,
                        vertical: 12,
                      ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: const BorderSide(color: Color(0xFFE5E7EB)),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: const BorderSide(color: Color(0xFFE5E7EB)),
                      ),
                    ),
                    items: _statusOptions
                        .map(
                          (s) => DropdownMenuItem(
                            value: s['value'],
                            child: Text(
                              s['label']!,
                              style: GoogleFonts.ibmPlexSans(fontSize: 14),
                            ),
                          ),
                        )
                        .toList(),
                    onChanged: (v) =>
                        setState(() => _selectedStatus = v ?? 'planning'),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              _buildField(
                'Description',
                _descCtrl,
                'Brief project scope and objectives',
                maxLines: 3,
              ),
              const SizedBox(height: 24),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.pop(context),
                      child: const Text('Cancel'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    flex: 2,
                    child: ElevatedButton(
                      onPressed: _isSaving ? null : _save,
                      child: _isSaving
                          ? const SizedBox(
                              height: 18,
                              width: 18,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Colors.white,
                              ),
                            )
                          : const Text('Create Project'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildField(
    String label,
    TextEditingController controller,
    String hint, {
    String? Function(String?)? validator,
    TextInputType keyboardType = TextInputType.text,
    int maxLines = 1,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: GoogleFonts.ibmPlexSans(
            fontSize: 13,
            fontWeight: FontWeight.w600,
            color: AppTheme.onSurface,
          ),
        ),
        const SizedBox(height: 6),
        TextFormField(
          controller: controller,
          keyboardType: keyboardType,
          maxLines: maxLines,
          validator: validator,
          style: GoogleFonts.ibmPlexSans(
            fontSize: 14,
            color: AppTheme.onSurface,
          ),
          decoration: InputDecoration(
            hintText: hint,
            filled: true,
            fillColor: AppTheme.surfaceVariant,
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 14,
              vertical: 12,
            ),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: const BorderSide(color: Color(0xFFE5E7EB)),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: const BorderSide(color: Color(0xFFE5E7EB)),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: const BorderSide(color: AppTheme.primary, width: 2),
            ),
            errorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: const BorderSide(color: AppTheme.errorColor),
            ),
          ),
        ),
      ],
    );
  }
}
