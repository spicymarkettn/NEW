import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

enum ProjectStatus { onTrack, atRisk, delayed, completed, planning, onHold }

enum TaskStatus { pending, inProgress, completed, blocked }

class StatusBadgeWidget extends StatelessWidget {
  final String label;
  final Color backgroundColor;
  final Color textColor;
  final double? fontSize;

  const StatusBadgeWidget({
    super.key,
    required this.label,
    required this.backgroundColor,
    required this.textColor,
    this.fontSize,
  });

  factory StatusBadgeWidget.fromProjectStatus(ProjectStatus status) {
    switch (status) {
      case ProjectStatus.onTrack:
        return StatusBadgeWidget(
          label: 'On Track',
          backgroundColor: const Color(0xFFCCEDE5),
          textColor: const Color(0xFF0D7B5E),
        );
      case ProjectStatus.atRisk:
        return StatusBadgeWidget(
          label: 'At Risk',
          backgroundColor: const Color(0xFFFEF3C7),
          textColor: const Color(0xFFB45309),
        );
      case ProjectStatus.delayed:
        return StatusBadgeWidget(
          label: 'Delayed',
          backgroundColor: const Color(0xFFFFE4E4),
          textColor: const Color(0xFFB91C1C),
        );
      case ProjectStatus.completed:
        return StatusBadgeWidget(
          label: 'Completed',
          backgroundColor: const Color(0xFFE5E7EB),
          textColor: const Color(0xFF374151),
        );
      case ProjectStatus.planning:
        return StatusBadgeWidget(
          label: 'Planning',
          backgroundColor: const Color(0xFFD6E4F7),
          textColor: const Color(0xFF1A56A0),
        );
      case ProjectStatus.onHold:
        return StatusBadgeWidget(
          label: 'On Hold',
          backgroundColor: const Color(0xFFF3F4F6),
          textColor: const Color(0xFF6B7280),
        );
    }
  }

  factory StatusBadgeWidget.fromTaskStatus(TaskStatus status) {
    switch (status) {
      case TaskStatus.pending:
        return StatusBadgeWidget(
          label: 'Pending',
          backgroundColor: const Color(0xFFF3F4F6),
          textColor: const Color(0xFF6B7280),
        );
      case TaskStatus.inProgress:
        return StatusBadgeWidget(
          label: 'In Progress',
          backgroundColor: const Color(0xFFD6E4F7),
          textColor: const Color(0xFF1A56A0),
        );
      case TaskStatus.completed:
        return StatusBadgeWidget(
          label: 'Completed',
          backgroundColor: const Color(0xFFCCEDE5),
          textColor: const Color(0xFF0D7B5E),
        );
      case TaskStatus.blocked:
        return StatusBadgeWidget(
          label: 'Blocked',
          backgroundColor: const Color(0xFFFFE4E4),
          textColor: const Color(0xFFB91C1C),
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: backgroundColor,
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(
        label,
        style: GoogleFonts.ibmPlexSans(
          fontSize: fontSize ?? 11,
          fontWeight: FontWeight.w600,
          color: textColor,
          letterSpacing: 0.2,
        ),
      ),
    );
  }
}
